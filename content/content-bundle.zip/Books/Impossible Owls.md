Full Title: Impossible Owls
Author: [[Brian Phillips]]
Category: books
Document Tags: [[Philosophy MOC]] [[Writing MOC]]

## Highlights & Notes
> [!quote] Highlight
>  The intense concentration of self in the middle of such a heartless immensity  ^392911976
> > [!note] Note
> > 
> > 

