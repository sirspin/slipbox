Full Title: Real Estate
Author: [[Deborah Levy]]
Category: books
Document Tags: [[Fiction MOC]] [[Philosophy MOC]] [[Writing MOC]]

## Highlights & Notes
> [!quote] Highlight
>  ‘Home is where the haunt is,’ wrote the late, great essayist Mark Fisher, and that was certainly true for me.  ^392911956
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  If I were asked to name the chief benefit of the house, I should say: the house shelters daydreaming, the house protects the dreamer, the house allows one to dream in peace. Gaston Bachelard, The Poetics of Space (1964)  ^392911957
> > [!note] Note
> > 
> > 

