Full Title: The Overstory
Author: [[Richard Powers]]
Category: books
Document Tags: [[Fiction MOC]] [[Philosophy MOC]] [[Writing MOC]]

## Highlights & Notes
> [!quote] Highlight
>  “Look the color!” And again, a few minutes later, a whisper to himself under the sky’s collapsing cobalt: Look the color! There are colors in his spectrum that no one else can see.  ^392911955
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  real joy consists of knowing that human wisdom counts less than the shimmer of beeches in a breeze. As certain as weather coming from the west, the things people know for sure will change. There is no knowing for a fact. The only dependable things are humility and looking.  ^399454605
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  “Pareidolia,” Patricia says. The translator doesn’t know the word. Patricia explains: the adaptation that makes people see people in all things. The tendency to turn two knotholes and a gash into a face. The translator says that’s not a thing in Portuguese.  ^411488407
> > [!note] Note
> > 
> > 

