Full Title: The Scumbag Economy
Author: [[Ed Zitron]]
Category: articles
Document Tags: [[Sociology MOC]] [[Worklife MOC]] 
URL: https://ez.substack.com/p/the-scumbag-economy

## Highlights & Notes
> [!quote] Highlight
>  When workers began to quit their jobs and take their business - the business of providing labor for money - elsewhere, they were accused of a lack of loyalty, and for participating in a pandemic-level “great resignation.” Leaders accused workers of “staying at home in their pajamas” with no justification, all while the companies they worked for made large amounts of money.  ^398757864
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  And when they were done making money, they kicked the same workers out the front door, claiming that “tough times required tough decisions and efficiency,” a thing that didn’t seem to matter when it came to remote work, or over-hiring to scoop up profits, or massive marketing spends.  ^398757865
> > [!note] Note
> > 
> > 

