Full Title: An Epicurean guide to happiness
Author: [[Julian Baggini]]
Category: articles
URL: https://www.theguardian.com/books/2023/jan/26/living-for-pleasure-by-emily-a-austin-an-epicurean-guide-to-happiness
Tags: [[Life Design MOC]] [[Philosophy MOC]]

## Highlights & Notes
> [!quote] Highlight
>  Pursue what is of real value to you, not what society tells you is most important.  ^468049783
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Epicurus’s distinctive feature is his insistence that pleasure is the source of all happiness and is the only truly good thing. Hence the modern use of “epicurean” to mean gourmand.  ^468049784
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  He thought the greatest pleasure was [[Ataraxia]]: a state of tranquility in which we are free from anxiety.  ^468049785
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  freedom from anxiety sounds pretty attractive. How can we get it? Mainly by satisfying the right desires and ignoring the rest.  ^468049786
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  “Those who least need extravagance enjoy it most,” the philosopher writes. Believing that only haute cuisine is good enough for you is a recipe for dissatisfaction.  ^468049836
> > [!note] Note
> > 
> > 

