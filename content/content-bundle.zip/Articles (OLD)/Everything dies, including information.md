Full Title: Everything dies, including information
Author: [[Erik Sherman]]
Category: articles
Document Tags: [[Sociology MOC]] 
URL: https://www.technologyreview.com/2022/10/26/1061308/death-of-information-digitization/

## Highlights & Notes
> [!quote] Highlight
>  what we think is permanent isn’t. Digital storage systems can become unreadable in as little as three to five years. Librarians and archivists race to copy things over to newer formats.  ^408772506
> > [!note] Note
> > 
> > 

