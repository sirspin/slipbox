Full Title: Where to Live
Author: [[Simon Sarris]]
Category: articles
Document Tags: [[Life Design MOC]] [[Psychology MOC]] 
URL: https://simonsarris.substack.com/p/where-to-live

## Highlights & Notes
> [!quote] Highlight
>  Cities seem to exert themselves on people, like a kind of peer-pressure, and they do it so thoroughly I’m not sure the people inside the cities fully know it.  ^389113698
> > [!note] Note
> > It's not cities that exert peer pressure, but the closeness with other humans. The community-first aspect of cities means that your decisions are driven more by other people, which is common sense. Cities adopt shared aesthetics and identities because of this phenomenon, while rural settings adopt shared aesthetics and identities because of the requirements of surviving in that setting.
> > 

> [!quote] Highlight
>  The really important thing isn’t where you live exactly, but being embodied in your living regardless of where you are. Perhaps that’s the interesting topic here, but it will have to wait for now.  ^389113699
> > [!note] Note
> > 
> > 

