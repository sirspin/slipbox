Full Title: The Best Idea Humans Ever Had
Author: [[David Cain]]
Category: articles
Document Tags: [[Life Design MOC]] [[Philosophy MOC]] [[Religion MOC]] [[Worklife MOC]] 
URL: https://www.raptitude.com/2022/10/the-best-idea-humans-ever-had/

## Highlights & Notes
> [!quote] Highlight
>  Live most of your days according to your normal habits, doing your job and your everyday stuff the same as always. Then one day a week, let’s say Tuesday, you live by a specific dictum: From the minute you wake up, do without hesitation the thing that most needs to be done in each moment, regardless of how appealing it is. Bring your full attention to each such act, as though it’s your sole purpose on earth. Let go of every other concern.  ^411700417
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  As Marcus Aurelius promised in his version of this dictum, “. . . a man has but to observe these few counsels, and the Gods will ask nothing more.”  ^411699736
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  it’s not about executing a perfect day. It’s about devoting yourself to the best possible use of your life that day, and seeing what happens.  ^411699743
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Essentially you’re playing a game of “One for me, one for my best self and the good of the world. One for me . . .“ It raises an interesting question: who is “me” if it conflicts with your best self and the good of the world? And why are we giving it half the proceeds of our lives?  ^411699781
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The Stoic tradition, the Buddhist tradition, and the Biblical tradition all propose an everyday version of Do-the-Right-Thing-At-Every-Moment Day.  ^411700418
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Your actions have a powerful compounding effect, after all. They affect your own future in dramatic ways, as well as the futures of all the people you interact with, and who they interact with, and so on.  ^411700419
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Every little act, right down to the attitude you’re carrying when you step onto the bus, is a moral choice with ever-rippling consequences. It matters whether you indulge in complaining to your wife about the bad driver you encountered, or whether you look down on your co-worker for her decidedly self-important Instagram posts — and not just a little. Even slight goods and harms can compound easily, in our subsequent actions, attitudes, and relationships, echoing far beyond our own lives and even our own lifetimes. No wonder the ancients got so serious about this.  ^411700420
> > [!note] Note
> > 
> > 

