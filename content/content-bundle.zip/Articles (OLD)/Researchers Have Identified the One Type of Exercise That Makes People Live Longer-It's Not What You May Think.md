Full Title: Researchers Have Identified the One Type of Exercise That Makes People Live Longer-It's Not What You May Think
Author: [[Svati Narula]]
Category: articles
URL: https://www.outsideonline.com/health/wellness/social-fitness-happiness-longevity-waldinger/
Tags: [[Health MOC]]

## Highlights & Notes
> [!quote] Highlight
>  Strengthening relationship ties by exercising what experts call “social fitness” is the most influential brain and body hack.  ^472557584
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  “If you regularly feel isolated and lonely, it can be as dangerous as smoking half a pack of cigarettes a day or being obese,” Waldinger cautions.  ^472557585
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Across the study, neither wealth nor social class were correlated with happiness levels or longevity. Positive relationships, on the other hand, were consistently linked to happier, longer lives.  ^472557586
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  One systematic research review from 2010, including over 300,000 participants, suggests people with strong social ties are 50 percent more likely to survive over a given period than those with weak ties.  ^472557587
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Rather than aim for a total social rehaul, focus on improving the valued relationships you already have.  ^472558519
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  A great way to level up—and maintain—healthy relationships is by scheduling regular contact, virtual or in-person.  ^472558493
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  One exercise to keep your social muscles in good shape is by expanding your network.  ^472558458
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Do “emotional push-ups.” These include striking up conversations with strangers, saying thank you, or accepting compliments without deflection. Start small—Practice one or two emotional push-ups weekly.  ^472558386
> > [!note] Note
> > 
> > 

