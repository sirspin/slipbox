Full Title: The Murders in Memphis Aren’t Stopping
Author: [[David Graham]]
Category: articles
Document Tags: [[Sociology MOC]] 
URL: https://www.theatlantic.com/ideas/archive/2022/11/memphis-violence-reduction-murder-crime-rate-policing/671877/

## Highlights & Notes
> [!quote] Highlight
>  A [2021 poll for the Memphis Shelby Crime Commission](https://memphiscrime.org/wp-content/uploads/2021/10/VOTER-SURVEY-re-Shelby-County-crime-neighborhoods-etc.pdf) found that Black voters in Shelby County were roughly split on their local police, with 51 percent giving a good rating and 47 percent a poor one, a substantial drop from 2020, with younger voters among the most skeptical.﻿ But the idea that Memphis, or the Black community nationally, is cleanly divided on police is false.  ^409220058
> > [!note] Note
> > 
> > 

