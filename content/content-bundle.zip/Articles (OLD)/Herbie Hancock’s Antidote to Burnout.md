Full Title: Herbie Hancock’s Antidote to Burnout
Author: [[Maria Popova]]
Category: articles
Document Tags: [[Life Design MOC]] [[Psychology MOC]] [[Worklife MOC]] 
URL: https://www.themarginalian.org/2022/12/22/herbie-hancock-interview-buddhism-burnout/

## Highlights & Notes
> [!quote] Highlight
>  We usually define ourselves by what we do: I’m a writer. Or I’m a doctor. Or I’m a dancer. Whatever it is. Or I do construction. That’s usually how we define ourselves. There’s a big trip with all of that.  ^440306405
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  We are makers of our own myths, but the more we live into them, the more we risk becoming their captives  ^440289904
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  All creativity rests upon unbelieving our own myths — seeing the world and our place in it afresh over and over, so that we may go on making what has not been made before, remaking ourselves in the process  ^440289919
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Burnout is simply what a creative person experiences when they have begun believing their own myth too much  ^440289920
> > [!note] Note
> > 
> > 

