URL: [https://slate.com/human-interest/2023/06/life-before-cell-phones-internet-after-work.html](https://slate.com/human-interest/2023/06/life-before-cell-phones-internet-after-work.html)
Author: [[Dan Kois]]
Publisher: [[Slate]]
Published Date: 2023-06-17
Top Note: Good lessons from the pre-smartphone era on how to set expectations re: work/life balance.
Tags: [[Sociology MOC]], [[Worklife MOC]]

## Highlights
> [!quote] Highlight
> Especially since the pandemic and the growth of remote work, job responsibilities seem to be ever-expanding to fill all available time.
> > > [!note] Note
> > With flexibility comes a lack of hierarchical oversight and an increase in hierarchical overreach
