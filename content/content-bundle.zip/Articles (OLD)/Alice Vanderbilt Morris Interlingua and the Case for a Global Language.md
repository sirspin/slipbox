Full Title: Alice Vanderbilt Morris: Interlingua and the Case for a Global Language
Author: [[Verity Heir]]
Category: articles
Document Tags: [[History MOC]] [[Sociology MOC]] 
URL: https://blue-stocking.org.uk/2013/03/03/alice-vanderbilt-morris-interlingua-and-the-case-for-a-global-language/

## Highlights & Notes
> [!quote] Highlight
>  As the world became increasingly more international in the twentieth century, with the rise of technology and more transportation options, there became a demand for a common language so that nations could communicate effectively without the use of translators.  ^444135021
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Overall, Vanderbilt Morris’ work towards creating a standardised language has contributed to establishing a mediator language for the present day. Although the case for the international auxiliary language and Interlingua ultimately failed, the ideals of a regularised vocabulary, grammar and syntax are being transferred and cultivating into a new interlanguage, Global English  ^444135244
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  English has become the global language due to colonisation and trading across the Asia and Africa over many centuries, and has rapidly become the *lingua franca* due to the invention of mobile phones and the internet whereby English is the default language  ^444135258
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  the English language is rapidly becoming simplified so that it could be learnt and used for communication across nations, not dissimilar to Vanderbilt Morris’ dream for Interlingua.  ^444135265
> > [!note] Note
> > 
> > 

