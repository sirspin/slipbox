Full Title: Yes You Can Wear Blue With Black, CHILL
Author: [[Blackbird Spyplane]]
Category: articles
Document Tags: [[Aesthetics MOC]] 
URL: https://www.blackbirdspyplane.com/p/wisdom-week-samuel-zelig-spygiveaway

## Highlights & Notes
> [!quote] Highlight
>  ![](https://substackcdn.com/image/fetch/w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2Fe6dfb41c-afbc-4cd5-844b-8b947f8513a5_2018x1026.png)  ^440306465
> > [!note] Note
> > 
> > 

