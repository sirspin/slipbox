Full Title: Ideas That Changed My Life
Author: [[Morgan Housel]]
Category: articles
Document Tags: [[Life Design MOC]] [[Philosophy MOC]] [[Sociology MOC]] 
URL: https://collabfund.com/blog/ideas-that-changed-my-life/

## Highlights & Notes
> [!quote] Highlight
>  Everyone belongs to a tribe and underestimates how influential that tribe is on their thinking.  ^438976236
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Everything’s been done before. The scenes change but the behaviors and outcomes don’t.  ^438976237
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Historian Niall Ferguson’s plug for his profession is that “The dead outnumber the living 14 to 1, and we ignore the accumulated experience of such a huge majority of mankind at our peril.”  ^438976238
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Communicate more effectively than your competition.  ^438979481
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Your personal experiences make up maybe 0.00000001% of what’s happened in the world but maybe 80% of how you think the world works.  ^438979482
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  People believe what they’ve seen happen exponentially more than what they read about has happened to other people, if they read about other people at all. We’re all biased to our own personal history.  ^438979483
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Start with the assumption that everyone is innocently out of touch and you’ll be more likely to explore what’s going on through multiple points of view, instead of cramming what’s going on into the framework of your own experiences.  ^438979484
> > [!note] Note
> > 
> > 

