Full Title: One Reason the World Seems So Troubled
Author: [[David Cain]]
Category: articles
Document Tags: [[Psychology MOC]] [[Sociology MOC]] 
URL: https://www.raptitude.com/2022/11/one-reason-the-world-seems-so-troubled/

## Highlights & Notes
> [!quote] Highlight
>  A boogeyman is a threatening portrayal of a person or thing, created on purpose, to drive people away from something: a business or an industry, a political opinion, a behavior. The hope is that the image is so off-putting that you won’t look closely enough to realize it’s a caricature.  ^425799917
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Your sense of “the way things are” is like a Hollywood horror movie, wherein a few disparate but memorable facts and images get connected, by large spans of inference and fiction, into an effective and satisfying story.  ^425799918
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  contriving a story of the world in which the things you fear most are prominent and growing, can motivate you to serve their private goals, which are probably to click, condemn, or praise whatever it is they want clicked, condemned, or praised.  ^425799919
> > [!note] Note
> > Fear is the ultimate motivator.
> > 

> [!quote] Highlight
>  Boogeymongering has limitless rhetorical power because limitless anxiety can be generated from a small seed of any significantly intense fear, regardless of how often it actually materializes in your direct experience. It’s an ancient art, but it’s easier than ever today, now that our lives are increasingly spent not directly experiencing the world itself, but instead browsing monetized depictions of the world on electronic devices.  ^425799920
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The human mind tends to fill in the blanks with bad things. This is negativity bias, which helped keep our ancestors alive.  ^425799921
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  we inherited a mind tuned for false positives. The human mind sees a dark room and habitually populates it with monsters, barely aware that it doesn’t actually know what’s there — that the darkness is the not-seeing, the not-knowing.  ^425799922
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  start by assuming that any news, activism, or political speech, right or wrong, is freely employing boogeymen.  ^425799923
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  A second reasonable assumption: if you have a completely partisan take on a contentious issue — as in, you do not believe there are any oversights in your side’s argument, no tradeoffs or complexities that might lead a decent person to a different stance — then you have probably been boogeymanned into those feelings to some extent.  ^425800229
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The boogeyman is a simple monster. Pure badness, pure wrongness.  ^425800230
> > [!note] Note
> > 
> > 

