Full Title: What Causes Burnout, and How to Prevent It
Author: [[Christina Maslach, Michael P. Leiter]]
Category: articles
Document Tags: [[Sociology MOC]] [[Worklife MOC]] 
URL: https://bigthink.com/leadership/what-causes-burnout/

## Highlights & Notes
> [!quote] Highlight
>  urn-out is a syndrome conceptualized as resulting from chronic workplace stress that has not been successfully managed. It is characterized by three dimensions:
> • feelings of energy depletion, or exhaustion.
> • increased mental distance from one’s job, or feelings of negativism or cynicism related to one’s job.
> • reduced professional efficacy.  ^444713807
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  We believe burnout arises from the increasing mismatch between workers and workplaces.  ^444713959
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  As the WHO definition explains, the occupational phenomenon of burnout is the result when chronic workplace stressors have “not been successfully managed.” If conditions and requirements set by a workplace are out of sync with the needs of people who work there, this bad fit in the person–job relationship will cause both to suffer.  ^444713969
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Our research has identified at least six forms of mismatch that can exist between a job and the person holding it:
> • work overload
> • lack of control
> • insufficient rewards
> • breakdown of community
> • absence of fairness
> • value conflicts  ^444713971
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Poor alignment in any one of these six areas increases the risk of burnout.  ^444713986
> > [!note] Note
> > 
> > 

