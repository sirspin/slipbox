Full Title: Thinking together
Author: [[Gordon Brander]]
Category: articles
Document Tags: [[Life Design MOC]] [[Psychology MOC]] 
URL: https://subconscious.substack.com/p/thinking-together

## Highlights & Notes
> [!quote] Highlight
>  Philosopher [[Paul Tillich]] posits that when social sensemaking fails to keep up with reality, we experience it as a kind of mass neurosis. Everybody has a crisis of meaning at the same time. Life stops making sense. Anyone living through 2016 onward knows that feeling. The Permaweird.  ^416015468
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  As our problems get more complex, our ability to meaningfully coordinate breaks down.  ^416015469
> > [!note] Note
> > 
> > 

