Full Title: Ithaka by C. P. Cavafy
Author: [[Anna Dalassené]]
Category: articles
Document Tags: [[Fiction MOC]] [[Poetry MOC]] [[Psychology MOC]] [[Writing MOC]] 
URL: https://www.poetryfoundation.org/poems/51296/ithaka-56d22eef917ec

## Highlights & Notes
> [!quote] Highlight
>  Keep Ithaka always in your mind.  ^388150505
> > [!note] Note
> > 
> > 

