Full Title: How to Stop Thinking Too Much
Author: [[David Cain]]
Category: articles
URL: https://www.raptitude.com/2022/11/how-to-stop-thinking-too-much/

## Highlights & Notes
> [!quote] Highlight
>  being caught up in your own thinking is like having been kidnapped and held hostage by the most boring person on earth.  ^480774578
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Even the most incessant and reactive stream of mental talk can occasionally be helpful (although how it helps, exactly, is a bigger discussion). In any case, mental talk does seem to vary immensely between individuals, in style and tone.  ^480774579
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  (a) most of us do experience some sort of mental talk, which habitually voices our impressions of the world, and (b) it sometimes dominates our experience in a very unpleasant way, especially when we’re feeling worry or anxiety.  ^480774580
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  You do it like this: 1. Notice that you’ve been caught up in thinking (i.e. held hostage by the boring kidnapper) 2. Don’t worry about halting the thinking. Instead, direct your attention to any physical corner — of the room, a window frame, a shelf, any place where two or more lines converge. Spend a few seconds looking at the corner, noticing its simple shape and color. 3. Turn your gaze to a different corner, and look at it for a few seconds. 4. Move your gaze like this to eight or ten different corners, spending a few seconds glimpsing at each one. When you switch corners, turn your whole head, not just your eyes.  ^480778639
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Corner Glimpsing also shows you that whether you’re stuck in your thoughts is really a question of where your attention is pointing, not whether there are thoughts occurring. The would-be kidnapper never runs out of stuff to say, but you’re the one who ultimately decides where the attention goes.  ^480778640
> > [!note] Note
> > 
> > 

