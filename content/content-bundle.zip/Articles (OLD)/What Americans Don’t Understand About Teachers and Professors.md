Full Title: What Americans Don’t Understand About Teachers and Professors
Author: [[Derek Thompson]]
Category: articles
Document Tags: [[Learning MOC]] [[Sociology MOC]] 
URL: https://www.theatlantic.com/newsletters/archive/2022/09/what-america-doesnt-understand-about-teachers-and-professors/671590/

## Highlights & Notes
> [!quote] Highlight
>  We talk about and reward teachers as becoming better at their craft the older their students are. College professors … make more money. But anyone who actually works in education knows that elementary teachers are, pound-for-pound, the best at what [they] do. First grade teachers move mountains everyday. Fourth grade teachers would make our best cult leaders if they weren’t justifiably exhausted all the time.  ^389920319
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Perhaps the most bizarre and borderline-exploitative part of the work is that today’s professors often write free articles for academic journals that they have to pay to access. “When we write articles for academic journals, we are not paid for the articles,” said Caitie, an associate professor.  ^389920320
> > [!note] Note
> > 
> > 

