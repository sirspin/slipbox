URL: [https://getmatter.com/email/26000974/?token=26000974%3Auhr9v5lyKDQBq29LGEuBsPV5R0E](https://getmatter.com/email/26000974/?token=26000974%3Auhr9v5lyKDQBq29LGEuBsPV5R0E)
Author: [[David Cain]]
Publisher: [[Raptitude]]
Published Date: 2023-06-12
Top Note: Good tip for [[Biz Plan]]
Tags: [[Worklife MOC]], [[Writing MOC]]

## Highlights
> [!quote] Highlight
> If you try to address everyone’s problems, you can’t compete with those who specialize.
> > [!quote] Highlight
> “Getting better at being human” is one the broadest topics imaginable. Humans do all sorts of things. Getting better at cooking omelets, or lying on the couch, could certainly count as “getting better at being human,” as could learning to make friends as an adult, recognizing beauty in the mundane, coping with self-destructive tendencies, staying sane in the too-much-information age, and ten thousand other things. Each of these concerns could be a niche one might specialize in.
> > [!quote] Highlight
> When I ask people why they subscribe to this site, trying to tease out common concerns I might help the readership with, they always say “I just like the way you think! Keep it up!” or “You say things I was thinking but didn’t know how to say.”
> > > [!note] Note
> > Tip for Writing MOC
