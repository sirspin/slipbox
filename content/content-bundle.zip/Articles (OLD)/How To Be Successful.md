Full Title: How To Be Successful
Author: [[Sam Altman]]
Category: articles
Document Tags: [[Life Design MOC]] [[Sociology MOC]] [[Worklife MOC]] 
URL: https://blog.samaltman.com/how-to-be-successful

## Highlights & Notes
> [!quote] Highlight
>  Most people get bogged down in linear opportunities. Be willing to let small opportunities go to focus on potential step changes.  ^411683622
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  If you don’t believe in yourself, it’s hard to let yourself have contrarian ideas about the future. But this is where most value gets created.  ^411683623
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Self-belief alone is not sufficient—you also have to be able to convince other people of what you believe. All great careers, to some degree, become sales jobs.  ^411685735
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Taking risks is important because it’s impossible to be right all the time—you have to try many things and adapt quickly as you learn more.  ^411685736
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Almost everyone I’ve ever met would be well-served by spending more time thinking about what to focus on.  ^411685737
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  To be willful, you have to be optimistic—hopefully this is a personality trait that can be improved with practice. I have never met a very successful pessimistic person.  ^411685738
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  You get truly rich by owning things that increase rapidly in value. This can be a piece of a business, real estate, natural resource, intellectual property, or other similar things. But somehow or other, you need to own equity in something, instead of just selling your time. Time only scales linearly. The best way to make things that increase rapidly in value is by making things people want at scale.  ^411685739
> > [!note] Note
> > The key to success is finding a way to passively own things which generate income, allowing you to spend your days on things that are good and true.
> > 

