Full Title: The Death of Intellectual Curiosity
Author: [[Naval Ravikant]]
Category: articles
Document Tags: [[Learning MOC]] [[Life Design MOC]] [[Psychology MOC]] 
URL: https://svenschnieders.github.io/curiosity/

## Highlights & Notes
> [!quote] Highlight
>  The only information most people consume is the news and other news-like content; they rarely read books.  ^398746744
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  lifelong learning is not something that academics can persuade people to do, rather it is a natural consequence of intellectual curiosity.  ^398750286
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Academics—not realizing this distinction—have been trying to persuade people into becoming lifelong learners by highlighting the importance of it; they should instead foster the natural curiosity and critical thinking of their students.  ^398750287
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  we know that there are mental models and theories which predict the future more accurately.  ^398750288
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Also notice that we can only make those models “less wrong” and never perfect. This idea of falsification was popularized by [[Karl Popper]] and is the foundation of—all serious—modern science. The result of this epistemological viewpoint is that we need to be prepared for any of our mental models (theories) to be falsified at any given time because we can never be certain that something is true; there is no authority we can ask for the truth.  ^398750289
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Changes like this rarely happen because the former mental model is less complex and an easy “one fits all solution.” There is a strong bias for being consistent with your past choices and opinions, which makes changing them even more challenging.  ^398750726
> > [!note] Note
> > We all would rather stick to comfortability. Challenging yourself is opening yourself up to risk – risk of being wrong, of the implications of being wrong.
> > 

> [!quote] Highlight
>  There is no longer a central authority to decide what knowledge is “true” and “important enough” to be taught. The same thing the internet did to media is now happening to education.  ^398751859
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The possibilities of educating yourself on the internet will only increase. To take advantage of this shift in education, the only thing you need is intellectual curiosity—to see learning as something you do for fun in your “free time.”  ^398751860
> > [!note] Note
> > 
> > 

