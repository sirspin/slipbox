Full Title: Oatly: The New Coke
Author: [[Nat Eliason]]
Category: articles
Document Tags: [[Health MOC]] [[Science MOC]] [[Sociology MOC]] 
URL: https://every.to/almanack/oatly-the-new-coke-821556

## Highlights & Notes
> [!quote] Highlight
>  Strawman the Disagreements: When people criticize the ingredients or health claims, strawman their arguments by focusing on the most easily dismissed criticisms, or by pointing the finger elsewhere.  ^400714169
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Oatly’s second ingredient after the oat base is “low erucic acid rapeseed oil” which is another name for canola oil.  ^400714170
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The evidence for the harms of canola oil is still in its early days, but continues to grow. Research has linked it to: Memory impairment [1], Alzheimer’s risk [1], Cardiovascular disease [2], [5], [6], [8], Diabetes [2], Increased all-cause mortality [2], [6], [7], Metabolic syndrome [3], Decreased brain function [4], and Oxidative stress [5], [7].  ^400714171
> > [!note] Note
> > 
> > 

