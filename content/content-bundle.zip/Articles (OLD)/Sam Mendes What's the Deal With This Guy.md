Full Title: Sam Mendes: What's the Deal With This Guy?
Author: [[Scott Tobias]]
Category: articles
Document Tags: [[Film MOC]], [[Aesthetics MOC]]
URL: https://thereveal.substack.com/p/sam-mendes-whats-the-deal-with-this

## Highlights & Notes
> [!quote] Highlight
>  ![] ^441059415
> > [!note] Note
> > 
> > 

