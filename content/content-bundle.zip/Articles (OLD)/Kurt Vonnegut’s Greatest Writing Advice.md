Full Title: Kurt Vonnegut’s Greatest Writing Advice
Author: [[Emily Temple]]
Category: articles
Document Tags: [[Life Design MOC]] [[Worklife MOC]] [[Writing MOC]] 
URL: https://getpocket.com/explore/item/kurt-vonnegut-s-greatest-writing-advice?utm_source=pocket-newtab

## Highlights & Notes
> [!quote] Highlight
>  Here is a lesson in creative writing. First rule: Do not use semicolons.  ^415934929
> > [!note] Note
> > 
> > ['favorite']

> [!quote] Highlight
>  The arts are not a way to make a living. They are a very human way of making life more bearable. Practicing an art, no matter how well or badly, is a way to make your soul grow, for heaven’s sake.  ^415934931
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  When you exclude plot, when you exclude anyone’s wanting anything, you exclude the reader, which is a mean-spirited thing to do.  ^415934932
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Businessmen would achieve better results if they studied human metabolism. No one works well eight hours a day. No one ought to work more than four hours.  ^415940312
> > [!note] Note
> > 
> > ['favorite']

> [!quote] Highlight
>  Simplicity of language is not only reputable, but perhaps even sacred.  ^415940313
> > [!note] Note
> > 
> > 

