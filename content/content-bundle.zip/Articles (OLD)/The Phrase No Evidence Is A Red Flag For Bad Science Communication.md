Full Title: The Phrase "No Evidence" Is A Red Flag For Bad Science Communication
Author: [[Scott Alexander]]
Category: articles
Document Tags: [[Science MOC]] [[Writing MOC]] 
URL: https://astralcodexten.substack.com/p/the-phrase-no-evidence-is-a-red-flag

## Highlights & Notes
> [!quote] Highlight
>  If it’s worth writing a story about why there’s no evidence for something, probably it’s because some people believe there is evidence. What evidence do they believe in? Why is it wrong? How do you know?  ^385247517
> > [!note] Note
> > Writing tip: Acknowledge early and often the context and those who oppose you!
> > 

