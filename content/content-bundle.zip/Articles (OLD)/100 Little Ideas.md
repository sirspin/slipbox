URL: [https://www.collaborativefund.com/blog/100-little-ideas/](https://www.collaborativefund.com/blog/100-little-ideas/)
Author: [[Morgan Housel]]
Publisher: [[Collaborative Fund]]
Published Date: 2020-02-20
Tags: [[Psychology MOC]], [[Sociology MOC]]

## Highlights
> [!quote] Highlight
> Curse of Knowledge: The inability to communicate your ideas because you wrongly assume others have the necessary background to understand what you’re talking about.
> > [!quote] Highlight
> Three Men Make a Tiger: People will believe anything if enough people tell them it’s true. It comes from a Chinese proverb that if one person tells you there’s a tiger roaming around your neighborhood, you can assume they’re lying. If two people tell you, you begin to wonder. If three say it’s true, you’re convinced there’s a tiger in your neighborhood and you panic.
> > [!quote] Highlight
> Pareto Principle: The majority of outcomes are driven by a minority of events.
> > [!quote] Highlight
> Anscombe’s Quartet: Four sets of numbers that look identical on paper (mean average, variance, correlation, etc.) but look completely different when graphed. Describes a situation where exact calculations don’t offer a good representation of how the world works.
> > [!quote] Highlight
> Semmelweis Reflex: Automatically rejecting evidence that contradicts your tribe’s established norms. Named after a Hungarian doctor who discovered that patients treated by doctors who wash their hands suffer fewer infections, but struggled to convince other doctors that his finding was true.
> > [!quote] Highlight
> Chronological Snobbery: “The assumption that whatever has gone out of date is on that account discredited. You must find why it went out of date. Was it ever refuted (and if so by whom, where, and how conclusively) or did it merely die away as fashions do? If the latter, this tells us nothing about its truth or falsehood. From seeing this, one passes to the realization that our own age is also ‘a period,’ and certainly has, like all periods, its own characteristic illusions.” – C.S. Lewis
> > [!quote] Highlight
> Berkson’s Paradox: Strong correlations can fall apart when combined with a larger population. Among hospital patients, motorcycle crash victims wearing helmets are more likely to be seriously injured than those not wearing helmets. But that’s because most crash victims saved by helmets did not need to become hospital patients, and those without helmets are more likely to die before becoming a hospital patient.
> > [!quote] Highlight
> Group Attribution Error: Incorrectly assuming that the views of a group member reflect those of the whole group.
> > [!quote] Highlight
> Baader-Meinhof Phenomenon: Noticing an idea everywhere you look as soon as it’s brought to your attention in a way that makes you overestimate its prevalence.
> > [!quote] Highlight
> Poisoning the Well: Presenting irrelevant adverse information about someone in a way that makes everything else that person says seem untrustworthy. “Before you hear my opponent’s healthcare plan, let me remind you that he got a DUI in college.”
> > [!quote] Highlight
> Weasel Words: Phrases that appear to have meaning but convey nothing tangible. “Growth was solid last quarter,” or “Many people believe.”
> 