Full Title: The Secret of Happiness Is That There Are Three Kinds
Author: [[Étienne Fortier-Dubois]]
Category: articles
Document Tags: [[Life Design MOC]] [[Philosophy MOC]] [[Psychology MOC]] [[Sociology MOC]] 
URL: https://etiennefd.substack.com/p/the-secret-of-happiness-is-that-there

## Highlights & Notes
> [!quote] Highlight
>  psychological richness.  ^438979485
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Hedonism is goodness that focusses on comfort, security, pleasure, and having money, time and fulfilling relationships.  ^438980328
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Eudaimonia is goodness that focusses on having a purpose, upholding moral principles, and contributing to society.  ^438980329
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  While this dichotomy is conceptually useful, it doesn’t imply stark opposition.  ^438980330
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Psychological richness is goodness that focusses on having interesting experiences, novelty, changes in perspective, and adventure.  ^438980563
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  my whole personality seems geared towards psychological richness. I’m endlessly curious, and I can nerd out about almost any topic; I even have trouble defining what I’m interested in (for example, in order to describe this newsletter) because there are too many things that could fit.  ^438981090
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  This quest for diversity has even been an obstacle to, for example, adopting vegetarianism. I know that you can eat well (happily) without meat; I care somewhat about the (meaningful) ethical implications; but eating a diverse diet, for me, trumps both of these concerns. A diet without meat is strictly less diverse than a diet with it, so to me it is inferior.  ^438981091
> > [!note] Note
> > 
> > 

