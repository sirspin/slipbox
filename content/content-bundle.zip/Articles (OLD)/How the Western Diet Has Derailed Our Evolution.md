Full Title: How the Western Diet Has Derailed Our Evolution
Author: [[Moises Velasquez-Manoff]]
Category: articles
URL: https://nautil.us/how-the-western-diet-has-derailed-our-evolution-235683/
Tags: [[Health MOC]] [[Food MOC]]

## Highlights & Notes
> [!quote] Highlight
>  The Western microbiome, the community of microbes scientists thought of as “normal” and “healthy,” the one they used as a baseline against which to compare “diseased” microbiomes, might be considerably different than the community that prevailed during most of human evolution.  ^466787295
> > [!note] Note
> > 
> > 

