Full Title: New York City Is a Lot Safer Than Small-Town America
Author: [[Justin Fox]]
Category: articles
Document Tags: [[Health MOC]] [[Sociology MOC]] [[Urbanism MOC]] 
URL: https://www.bloomberg.com/opinion/articles/2022-06-07/is-new-york-city-more-dangerous-than-rural-america

## Highlights & Notes
> [!quote] Highlight
>  The overall lesson seems to be that the more urban your surroundings, the less danger you face. High homicide rates in some cities mean that the central counties in large metropolitan areas are on the whole slightly more dangerous than the suburban counties, but that’s the only exception. The risk of death from truly external causes, as defined here, is three times higher in rural and small-town America than in the country’s largest city.  ^388156172
> > [!note] Note
> > 
> > 



URL: https://www.bloomberg.com/opinion/articles/2022-06-07/is-new-york-city-more-dangerous-than-rural-america
Author: [[helloworld]]
Date: [[07-26-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>The overall lesson seems to be that the more urban your surroundings, the less danger you face. High homicide rates in some cities mean that the central counties in large metropolitan areas are on the whole slightly more dangerous than the suburban counties, but that’s the only exception. The risk of death from truly external causes, as defined here, is three times higher in rural and small-town America than in the country’s largest city.<br>
>>[!note]
>>
</p>