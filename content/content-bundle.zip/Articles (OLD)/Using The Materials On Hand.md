Full Title: Using The Materials On Hand
Author: [[The Polymerist]]
Category: articles
Document Tags: [[Sociology MOC]] [[Urbanism MOC]] 
URL: https://polymerist.substack.com/p/using-the-materials-on-hand

## Highlights & Notes
> [!quote] Highlight
>  It appears that our climate is changing faster than our building codes. This is a problem.  ^401703389
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  My point is that figuring out new ways to use old materials can be just as useful as creating something completely new. The benefit of using something old is that most people probably understand what it means, and you don’t have to spend time trying to educate them. People don’t necessarily want more choices and more innovation, especially when it comes to something personal like a home. People want to be more confident in the choice that make and sometimes “new” doesn’t inspire that much confidence.  ^401705062
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  We have a plethora of challenges right now and building enough housing for people is one of them. Building better housing for those of us who will live through climate change occurring will likely become a theme in the next 10 years if it isn’t already happening. Maybe the answers are not in the direction of more complexity and robotic manufacturing or modular construction, but rather a simple and elegant technique for shaping concrete.  ^401705063
> > [!note] Note
> > 
> > 

