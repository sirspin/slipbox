Full Title: How to Beat Worry
Author: [[Lawrence Yeo]]
Category: articles
Document Tags: [[Life Design MOC]] [[Psychology MOC]] 
URL: https://moretothat.com/how-to-beat-worry/

## Highlights & Notes
> [!quote] Highlight
>  The reason why worry is such a difficult emotion to tackle is that awareness simply isn’t enough. To be aware of an emotion like anger often allows you to divorce its physiology from its poignancy, but being aware of your worry often has the opposite effect.  ^389920312
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The antidote to worry is not to be passively aware of it, but to take proactive steps to fix it.  ^389920314
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Even if you know that a concern is a small one (i.e. “I sent an email to my boss with a few typos”), any attempt to trivialize it won’t work because the concern itself isn’t what matters anymore. What matters is how the concern has led to the Bleak Thought (i.e. “My boss will think I’m an idiot from here on out”), and how that amplifies the importance of the event in question.  ^389920315
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  a worrier’s mind is extremely sensitive to anticipation.  ^389920316
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Since the mind is so attuned to how things may go wrong, a worrier feels like he’s perpetually waiting for something to happen.  ^389920317
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Our role as mindful mechanics is to go in and break these loops. But you don’t do that by telling yourself, “Hey, stop being stupid and stop worrying.” That’s a useless imperative. The way you do it is to approach each leg of the decision tree and provide a game plan to handle each option. The antidote to worry is not shame, but self-compassion.  ^389921128
> > [!note] Note
> > Counterpoint: I think a lot of people get trapped in planning as a way to avoid worry.
> > 

> [!quote] Highlight
>  By being patient and kind to yourself, you let go of the tendency to criticize and can see the rational solutions with more clarity.  ^389921129
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The way I see it is through the lens of what I call the Three D’s:  ^389921130
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  After a concern arises, you ask yourself if something can be done, and if the answer is “Yes,” some semblance of a solution will come to mind.  ^389921131
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  This is where you make the final decision by asking yourself these questions: How do you feel about the decision after doing nothing for 24 hours? Does it still feel like the right move to schedule that 1:1 with your boss to chat about what happened? Or does it feel unwarranted and overblown to do that?  ^389921134
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  (1) When a worry arises, notice that there’s only one question that matters: “Is there anything I can do about it?”  ^389921135
> > [!note] Note
> > 
> > 

