Full Title: The Universe Is Not Locally Real, and the Physics Nobel Prize Winners Proved It
Author: [[Daniel Garisto]]
Category: articles
Document Tags: [[Science MOC]] 
URL: https://www.scientificamerican.com/article/the-universe-is-not-locally-real-and-the-physics-nobel-prize-winners-proved-it/

## Highlights & Notes
> [!quote] Highlight
>  The trouble with quantum mechanics was never that it made the wrong predictions—in fact, the theory described the microscopic world splendidly well right from the start when physicists devised it in the opening decades of the 20th century.  ^396733712
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  What Einstein, Boris Podolsky and Nathan Rosen took issue with, laid out in their iconic 1935 paper, was the theory’s uncomfortable implications for reality.  ^396733713
> > [!note] Note
> > 
> > 

