Full Title: Every January, Make Two Lists
Author: [[David Cain]]
Category: articles
Document Tags: [[Life Design MOC]] 
URL: https://www.raptitude.com/2023/01/every-january-make-two-lists/

## Highlights & Notes
> [!quote] Highlight
>  List A consists of a few things you want to spend more of your life on, this year, than you have been recently. (ex. having friends over for coffee; tracking expenses in a spreadsheet) List B consists of a few things you want to spend less of your life on, this year, than you have been recently. (ex. doom-scrolling news sites; eating peanut butter out of the jar)  ^450883449
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  How we direct our moment-to-moment energies is how we spend our days, and how we spend our days is how we spend our lives.  ^450883450
> > [!note] Note
> > 
> > 

