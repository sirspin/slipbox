Full Title: Why Can’t I Commit to a Hobby?
Author: [[Katie Heaney]]
Category: articles
Document Tags: [[Life Design MOC]] [[Psychology MOC]] 
URL: https://www.thecut.com/2020/01/why-its-so-hard-to-commit-to-a-hobby.html

## Highlights & Notes
> [!quote] Highlight
>  having a hobby is really good for you.  ^461858756
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Hobbies make us happier because they contribute to our sense of identity; and because having a strong identity outside of work makes us more content at work, one could argue that having a hobby also makes for better employees.  ^461858757
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Having an “enjoyable leisure activity” (a.k.a. a hobby) is good for your physical health, too — one 2009 study published in Psychosomatic Medicine found that people who reported pleasurable and frequent participation in hobbies were found to have lower blood pressure, as well as perceptions of better physical function.  ^461858758
> > [!note] Note
> > 
> > 

