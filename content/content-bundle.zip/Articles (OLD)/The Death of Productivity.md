Full Title: The Death of Productivity
Author: [[Ed Zitron]]
Category: articles
Document Tags: [[Sociology MOC]] [[Worklife MOC]] 
URL: https://ez.substack.com/p/the-death-of-productivity

## Highlights & Notes
> [!quote] Highlight
>  Many remote workers have two jobs - their actual job, and the moronic sideshow of placating a manager that wants to think that you’re “busy.”  ^401701575
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  I’d argue that as businesses have grown the gulf between the producer and the recipient of the majority of the capital in the business (bosses and managers), businesses have become distanced from the concept of productivity entirely. As I wrote last year for The Altantic, we societally “tend to consider management a title rather than a skill, something to promote people to” rather than something people do, and the net result of this degenerative idea is that companies no longer actually care about production.  ^401702648
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  People are hired based on confirmed biases, aesthetics, charm, “culture fit” and anything other than “will they do this job well and make the business better without making everyone miserable,” because, realistically, so many people hiring and managing other people don’t know what the fuck it is they do.  ^401702649
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Productivity paranoia is the emperor feeling the breeze on his genitals despite his perfectly-appointed outfit. Anybody that has uttered or been concerned about this term acknowledges that they are not really interested in productivity, but in the warm feeling that they’re “getting the most” out of the people working for them. “Getting the most” out of someone without measuring their actual productivity - their production - is abjectly stupid, and yet appears to be how most business publications and managers evaluate their workers.  ^401702650
> > [!note] Note
> > 
> > 

