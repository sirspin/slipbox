Full Title: How the Personal Computer Broke the Human Body
Author: [[Matthew Gault]]
Category: articles
Document Tags: [[Health MOC]] 
URL: https://www.vice.com/en/article/y3dda7/how-the-personal-computer-broke-the-human-body

## Highlights & Notes
> [!quote] Highlight
>  There was really no precedent in our history of media interaction for what the combination of sitting and looking at a computer monitor did to the human body.  ^399785655
> > [!note] Note
> > This interim time in history, where our bodies and machines are not yet connected, has health ramifications.
> > 

> [!quote] Highlight
>  Our bodies, quite literally, were never meant to work this way.  ^399785656
> > [!note] Note
> > The human-computer interface is crude, rudimentary, and ripe for innovation. Sitting down at a terminal and manually inputting information is too many steps for effective synthesis between man and machine.
> > 

