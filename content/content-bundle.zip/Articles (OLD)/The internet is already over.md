Full Title: The internet is already over
Author: [[Sam Kriss]]
Category: articles
Document Tags: [[Philosophy MOC]] [[Technology MOC]] 
URL: https://samkriss.substack.com/p/the-internet-is-already-over

## Highlights & Notes
> [!quote] Highlight
>  There was an ancient thought: that Zeus feeds on the world. ‘The universe is cyclically consumed by the fire that engendered it.’  ^404665096
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Our God is a devourer, who makes things only for the swallowing. As it happens, this was the first thought, the first ever written down in a book of philosophy, the first to survive: that nothing survives, and the blankness that birthed you will be the same hole you crawl into again.  ^404665097
> > [!note] Note
> > 
> > 

