Full Title: Jazz Messenger
Author: [[Haruki Murakami]]
Category: articles
Document Tags: [[Fiction MOC]] [[Music MOC]] [[Poetry MOC]] [[Writing MOC]] 
URL: https://www.nytimes.com/2007/07/08/books/review/Murakami-t.html

## Highlights & Notes
> [!quote] Highlight
>  Still, I had no idea how to go about writing a novel or what to write about. I had absolutely no experience, after all, and no ready-made style at my disposal. I didn’t know anyone who could teach me how to do it, or even friends I could talk with about literature. My only thought at that point was how wonderful it would be if I could write like playing an instrument.  ^408671501
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Whether in music or in fiction, the most basic thing is rhythm.  ^408671502
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Your style needs to have good, natural, steady rhythm, or people won’t keep reading your work. I learned the importance of rhythm from music — and mainly from jazz.  ^408671503
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Next comes melody — which, in literature, means the appropriate arrangement of the words to match the rhythm.  ^408671504
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Then comes the part I like best: free improvisation. Through some special channel, the story comes welling out freely from inside. All I have to do is get into the flow.  ^408671506
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Finally comes what may be the most important thing: that high you experience upon completing a work — upon ending your “performance” and feeling you have succeeded in reaching a place that is new and meaningful.  ^408671507
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Practically everything I know about writing, then, I learned from music. It may sound paradoxical to say so, but if I had not been so obsessed with music, I might not have become a novelist.  ^408671508
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Once, when someone asked him how he managed to get a certain special sound out of the piano, Monk pointed to the keyboard and said: “It can’t be any new note. When you look at the keyboard, all the notes are there already. But if you mean a note enough, it will sound different. You got to pick the notes you really mean!”  ^408671509
> > [!note] Note
> > 
> > 

