Full Title: The Intellectual Obesity Crisis
Author: [[Gurwinder Bhogal]]
Category: articles
Document Tags: [[Psychology MOC]] [[Sociology MOC]] 
URL: https://gurwinder.substack.com/p/the-intellectual-obesity-crisis

## Highlights & Notes
> [!quote] Highlight
>  In an age of information overabundance, our curiosity, which once focused us, now distracts us  ^439651025
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The easiest strong emotion to evoke is outrage; it requires nothing more sophisticated than a simple story of oppression, tailored to the appropriate political tribe. And yet outrage, for all its cheapness, is highly addictive and highly contagious, making it the weapon of choice for anyone who wants to be noticed in the online cacophony. Even once-respected outlets like the *New York Times* now resort to "ragebait," sensationalist stories calculated to infuriate both the newspaper's readers and its political opponents, ensuring maximum attention  ^439653621
> > [!note] Note
> > Outrage / ragebaiting - another good PR concept related to propaganda
> > 

> [!quote] Highlight
>  A 2019 [study](https://newsroom.haas.berkeley.edu/how-information-is-like-snacks-money-and-drugs-to-your-brain/) by researchers at Berkeley found that information acts on the brain’s dopamine-producing reward system in the same way as food. Put simply, the brain treats information as a reward in itself; it doesn't matter whether the info is accurate or useful, the brain will still crave it and feel satisfied after consuming it (at least until it starts craving more).  ^439651071
> > [!note] Note
> > 
> > ['research']

> [!quote] Highlight
>  Since low-quality information is just as effective at satisfying our information-cravings as high-quality information, the most efficient way to get attention in the digital age is by mass-producing low-quality "junk info"— a kind of fast food for thought.  ^439651475
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Junk info is often false info, but it isn't junk because it's false. It's junk because it has no practical use; it doesn't make your life better, and it doesn't improve your understanding. Even lies can be nourishing; the works of Dostoevsky are fiction, yet can teach you more about humans than any psychology textbook.  ^439651493
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Common types of junk info include gossip, trivia, clickbait, hackery, marketing, [churnalism](https://en.wikipedia.org/wiki/Churnalism), and [babble](https://gurwinder.substack.com/p/the-opinion-pageant?s=w).  ^439651501
> > [!note] Note
> > "Junk info" could be a good concept for future exploration
> > 

> [!quote] Highlight
>  the junk info that spreads furthest of all is that which evokes strong emotions, and this hasn't gone unnoticed by those, such as journalists and commentators, who are most desperate for your attention.  ^439651606
> > [!note] Note
> > If it bleeds, it leads (again)
> > 

