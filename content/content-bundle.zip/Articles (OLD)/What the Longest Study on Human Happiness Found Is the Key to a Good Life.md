Full Title: What the Longest Study on Human Happiness Found Is the Key to a Good Life
Author: [[Marc Schulz]]
Category: articles
URL: https://www.theatlantic.com/ideas/archive/2023/01/harvard-happiness-study-relationships/672753/
Tags: [[Life Design MOC]]

## Highlights & Notes
> [!quote] Highlight
>  Looking in the mirror and thinking honestly about where your life stands is a first step in trying to live a good life.  ^480778684
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Noticing where you are can help put into relief where you would like to be.  ^480778685
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Loneliness has a physical effect on the body. It can render people more sensitive to pain, suppress their immune system, diminish brain function, and disrupt sleep, which in turn can make an already lonely person even more tired and irritable.  ^480780139
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Research has found that, for older adults, loneliness is far more dangerous than obesity.  ^480780140
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Alleviating this epidemic of loneliness is difficult because what makes one person feel lonely might have no effect on someone else.  ^480780141
> > [!note] Note
> > 
> > 

