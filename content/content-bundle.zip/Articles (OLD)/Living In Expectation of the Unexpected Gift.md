Full Title: Living In Expectation of the Unexpected Gift
Author: [[L. M. Sacasas]]
Category: articles
Document Tags: [[Life Design MOC]] [[Philosophy MOC]] [[Sociology MOC]] 
URL: https://theconvivialsociety.substack.com/p/living-in-expectation-of-the-unexpected

## Highlights & Notes
> [!quote] Highlight
>  “Really weird,” Gilliard noted, “how tech companies are all promising to offload your decision making so you can have time for ‘what matters.’ If you aren’t making any of these decisions, what’s left that matters?”  ^385247511
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  For some people at least, the idea seems to be that when we are freed from these mundane and tedious activities, we will be free to finally tap the real potential of our humanity. It’s as if there were some abstract plane of human existence that no one had yet achieved because we were fettered by our need to be directly engaged with the material world. I suppose that makes this a kind of gnostic fantasy. When we no longer have to tend to the world, we can focus on … what exactly?  ^385247512
> > [!note] Note
> > Humans seek to move beyond our physical restraints; We don't want the menial challenges of keeping up with our bodies and our planet. But our physical context is essential to our human-ness. We want to evolve, but doing so will change us. We feel the tension.
> > 

> [!quote] Highlight
>  Optimization becomes an end in itself. I may not know where I am going or why, but I can take some comfort in knowing that I can travel faster and more efficiently. Frenetic activity or compulsive distraction substitute for a clear sense of purpose and commitment. Substantive goals may elude me, but I can take refuge in tracking and optimizing an increasing range of activities and bodily functions.  ^385247514
> > [!note] Note
> > There are drawbacks to [[PKM]]. It's important to create, not just consume.
> > 

> [!quote] Highlight
>  Do not mistake planning for purpose, or activity for action. Attend to the ordinary and the mundane with care and with gratitude. Consider that rest is not a time set aside, but a spirit brought to every time. Refuse the ever-present temptation to control and manage the thing we call life for their is no surer way to miss it.  ^385247515
> > [!note] Note
> > Live in the moment, not the organization of the moment.
> > 

