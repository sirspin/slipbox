Full Title: Thoughts Are Made to Be Thrown Out
Author: [[David Cain]]
Category: articles
URL: https://www.raptitude.com/2023/02/thoughts-are-made-to-be-thrown-out/

## Highlights & Notes
> [!quote] Highlight
>  Recognizing thought for what it is — a mild hallucination that offers a physically safer form of trial and error — can spare us a lot of that kind of suffering.  ^480774574
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  We need to make sure we dispose of thoughts after they’ve made their appeal, because they’ll stick around as long as you let them.  ^480774575
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Throwing out thoughts is something to practice, using a technique like Corner Glimpsing or just by uttering an inner “No thanks” and doing something with the body instead. You just drop it and move, putting your attention into anything physical and real.  ^480774576
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  This “drop-and-move-on” move feels dangerous at first. This is because the mind knows you’re abandoning mental trial-and-error for the physical kind again, and the mind’s entire purpose is to keep the body from messing itself up in the real world. The mind forgets, though, that ultimately the body is the part of you that has to get on with things and live in that real world, and nothing good can happen until it starts doing that again.  ^480774577
> > [!note] Note
> > 
> > 

