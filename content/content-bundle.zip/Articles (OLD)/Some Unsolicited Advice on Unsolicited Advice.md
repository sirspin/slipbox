Full Title: Some Unsolicited Advice on Unsolicited Advice
Author: [[Rob Henderson]]
Category: articles
URL: https://robkhenderson.substack.com/p/some-unsolicited-advice-on-unsolicited
Tags: [[Sociology MOC]] [[History MOC]] [[Psychology MOC]]

## Highlights & Notes
> [!quote] Highlight
>  anthropological and sociological evidence indicates that generally speaking, people detest constraints on their freedom.  ^466781037
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Hunter-gatherer communities hate all forms of dominance. Hunter-gatherers generally believe it is wrong to coerce a person into doing what the person doesn’t want to do. They seldom even make direct suggestions, because it might sound like coercion.  ^466781038
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Perhaps people can accept abstract rules in the form of local norms and legal codes. But if it has a human face, if an individual directly tries to tell us what to do, we are naturally inclined to resent it.  ^466781039
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  psychologist Peter Gray has suggested that people seem to resent unsolicited advice more when it comes from loved ones. When strangers give us unsolicited advice, it doesn’t feel like a constraint on our autonomy, because we don’t care about pleasing them.  ^466781040
> > [!note] Note
> > 
> > 

