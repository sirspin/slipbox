Full Title: In Praise of the Gods
Author: [[Simon Sarris]]
Category: articles
Document Tags: [[Life Design MOC]] [[Religion MOC]] 
URL: https://simonsarris.substack.com/p/in-praise-of-the-gods

## Highlights & Notes
> [!quote] Highlight
>  The mythos we create is the opposite of nihilism, it is the definite optimism of the power of the world waiting be lured back by us.  ^385247516
> > [!note] Note
> > 
> > 

