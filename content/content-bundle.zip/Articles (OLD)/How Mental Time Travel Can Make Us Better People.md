Full Title: How Mental Time Travel Can Make Us Better People
Author: [[Katherine Harmon Courage]]
Category: articles
Document Tags: [[Life Design MOC]] [[Psychology MOC]] [[Sociology MOC]] 
URL: https://nautil.us/how-mental-time-travel-can-make-us-better-people-254241/

## Highlights & Notes
> [!quote] Highlight
>  Plenty of research has shown that thinking about the future [can shift](https://www.sciencedirect.com/science/article/abs/pii/S1053810016302252) our *intentions* to behave better, from planning to [save more money for retirement](https://hbr.org/2013/06/you-make-better-decisions-if-you-see-your-senior-self) to [helping out](https://pubmed.ncbi.nlm.nih.gov/29178984/) in a theoretical situation.  ^441061987
> > [!note] Note
> > 
> > ['research']

> [!quote] Highlight
>  thinking about the future is a powerful way to promote prosocial behavior in an indirect way.  ^441062190
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  it has been proposed that both mental simulations (future thinking and perspective-taking) rely on common regions of the brain. Thus, if we imagine a future scene, these brain regions are recruited, and this might facilitate other types of mental simulations such as viewing others’ mental states.  ^441062273
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  If we think about the future more often, we will become more likely to help each other. It also means that if we want others to behave in a more prosocial way, it may help to invite them to think about the future. This can apply to friends, family members, colleagues, and so forth.  ^441062291
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  In this study, we tested future thinking at the interpersonal level, so further research is required on the application of this intervention at the intergroup level  ^441062297
> > [!note] Note
> > 
> > 

