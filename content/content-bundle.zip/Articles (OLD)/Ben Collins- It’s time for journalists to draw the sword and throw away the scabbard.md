URL: [https://www.niemanlab.org/2023/06/ben-collins-its-time-for-journalists-to-draw-the-sword-and-throw-away-the-scabbard/](https://www.niemanlab.org/2023/06/ben-collins-its-time-for-journalists-to-draw-the-sword-and-throw-away-the-scabbard/)
Author: [[Ben Collins]]
Publisher: [[Nieman Lab]]
Published Date: 2023-06-13
Tags: [[Journalism MOC]] [[Sociology MOC]] [[Misinformation]]

## Highlights
> [!quote] Highlight
> We’re back in that very same battle right now, and it’s against the same enemy: ignorance, intolerance, indifference. The box is smaller now. It’s in your pocket. It’s brighter and faster and it vibrates and dings and brings you horror and joy and knows what makes you feel better and sure as hell knows what makes you feel worse. Then it assigns those bad feelings to a political enemy, and the good feelings to anybody trying to get rid of those people.
> 