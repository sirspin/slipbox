Full Title: In Praise of Idleness
Author: [[Bertrand Russell]]
Category: articles
Document Tags: [[Philosophy MOC]] [[Sociology MOC]] [[Worklife MOC]] 
URL: https://harpers.org/archive/1932/10/in-praise-of-idleness/

## Highlights & Notes
> [!quote] Highlight
>  In America men often work long hours even when they are already well-off; such men, naturally, are indignant at the idea of leisure for wage-earners except as the grim punishment of unemployment, in fact, they dislike leisure even for their sons.  ^385247509
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  only a foolish asceticism, usually vicarious, makes us insist on work in excessive quantities now that the need no longer exists.  ^385247510
> > [!note] Note
> > 
> > 

