Full Title: Who’s Left Out of the Learning-Loss Debate
Author: [[Keeanga-Yamahtta Taylor]]
Category: articles
Document Tags: [[Health MOC]] [[Learning MOC]] [[Sociology MOC]] 
URL: https://www.newyorker.com/news/essay/whos-left-out-of-the-learning-loss-debate

## Highlights & Notes
> [!quote] Highlight
>  According to the Pew Research Center, Black parents tended to worry about the health and safety of their children and teachers. White parents also worried about the safety of teachers, but they tended to worry more about the impact of school closures on their children’s academic achievements than their children contracting COVID.  ^398755153
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  There is little effort to understand the deep mistrust Black parents have for school administrators and local officials who have lied to them before about the safety of their children’s schools and the potential threats to their children’s health.  ^398755155
> > [!note] Note
> > There is historic mistrust for many authoritative figures in the Black community. How do we solve those challenges? Time?
> > 

> [!quote] Highlight
>  A real plan for recovery from the devastation of the pandemic in public education can be found in the strikes initiated by teachers and their unions.  ^398755157
> > [!note] Note
> > 
> > 

