Full Title: The Disconnection of Tech Bros from Tech
Author: [[Ed Zitron]]
Category: articles
Document Tags: [[Sociology MOC]] [[Technology MOC]] 
URL: https://ez.substack.com/p/the-disconnection-of-tech-bros-from

## Highlights & Notes
> [!quote] Highlight
>  What is a good actor, exactly? Who is the arbiter of what good actors (or actions) are? Is a good actor a political activist? What if they’re an activist that has been critical of the police? Would they have anonymity? Does anonymity mean true anonymity, or does it mean that only a few people know who someone is? Is someone able to be purely anonymous, or do they have to reveal their identity to the platforms? What if their identity doesn’t fit into a box designed by (and for) cis-gendered people?  ^395754033
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  while we’re on the subject - who is the platform here, exactly? Does each platform identify each person? And what if the person in question doesn’t have the “right” kind of papers, such as someone who doesn’t have a driver’s license, or a birth certificate?  ^395754037
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  because Scott Galloway has likely never run afoul of the police, nor does he have any concern about what a run-in with the police might look like, he has never considered the extremely obvious ramifications of why being anonymous online is a necessary option.  ^395754111
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  He either knew he was wrong, and that his “core” audience (white people who want to know what opinions to have about technology) won’t care, or he truly believes he’s right, which means that he may lack even the most rudimentary understanding of how the internet works or how governments treat digital dissent.  ^395756234
> > [!note] Note
> > 
> > 

