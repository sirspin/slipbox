Full Title: Quiet Quitting Is Hustle Culture's Reckoning
Author: [[Ed Zitron]]
Category: articles
Document Tags: [[Sociology MOC]] [[Worklife MOC]] 
URL: https://ez.substack.com/p/quiet-quitting-is-hustle-cultures

## Highlights & Notes
> [!quote] Highlight
>  If quiet quitting actually exists, people realize that hard work isn’t what makes you a success, which undermines the business model of hustle culture hustlers but also erodes their entire mythology.  ^395757686
> > [!note] Note
> > Hustle culture is a myth, perpetuated by those who stand to make financial gain.
> > 

