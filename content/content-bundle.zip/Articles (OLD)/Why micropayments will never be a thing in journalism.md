Full Title: Why micropayments will never be a thing in journalism
Author: [[James Ball]]
Category: articles
URL: https://www.cjr.org/opinion/micropayments-subscription-pay-by-article.php
Tags: [[Journalism MOC]]

## Highlights & Notes
> [!quote] Highlight
>  there is, it turns out, a long list of reasons you can’t pay for journalism by the article—and why you shouldn’t expect to see the idea catch on anytime soon.  ^482301804
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  One of the core reasons publishers are reluctant to adopt this mechanism is that most publications are conceived as package deals. Premium outlets want to sign up subscribers, especially on recurrent payment plans. That means you decide once, and then the cost to you is invisible.  ^482301805
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  if a subscription is worth a hundred dollars a year to a publisher, then even one person clicking on the twenty-cent button instead means the publisher needs five hundred people to buy articles to make up for the lost revenue. The ratios are different for different outlets, but the math remains intimidating.  ^482301806
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  There’s also a philosophical objection. As noted, newspapers and magazines have been conceived as a package—a mix of the light and the heavy. Some stories cost far more to produce than others, but it balances out because you buy the whole thing. That logic dies if you separate them out.  ^482301807
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Gaming is perhaps the greatest triumph of micropayments. But in games, you know what you’re buying in advance—three extra lives, a hundred coins, whatever. For a journalistic article, you’ll only know whether you enjoyed it after you’ve finished it.  ^482301808
> > [!note] Note
> > The gamification of news is the answer! #Idea
> > 

> [!quote] Highlight
>  Media companies would need to devise a low-friction method for users to pay across sites owned by dozens of different publishers, without new log-ins and usernames each time. That would require lots of sites to take the plunge at once, agreeing on a system and a payment provider—which would presumably need to take a cut in order to keep operating.  ^482301809
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  “It’s Haile’s first law of media,” he says. “The success of any project is inversely correlated with the amount that requires publishers to work together.”  ^482301810
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  There are more problems still—difficulties in delineating which content would be paid for versus free, challenges with advertising, problems with middlemen. But they all amount to a core issue.  ^482301811
> > [!note] Note
> > 
> > 

