Full Title: Cozy futurism
Author: [[José Luis Ricón (Artir)]]
Category: articles
Document Tags: [[Sociology MOC]] [[Technology MOC]] [[Urbanism MOC]] 
URL: https://nintil.com/cozy-futurism

## Highlights & Notes
> [!quote] Highlight
>  cozy futurism, as in the original tweet, starts not with technology but with current problems and human needs and looking at how those could be solved and met;  ^386238682
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Cozy futurism is distinct from solarpunk; solar punk seems to stress a retrofuturistic aesthetic, some sense of return to nature, perhaps smaller cooperatives instead of large corporations, a sense of self-reliance, urban agriculture, or distributed, renewable-based power grids. I'd say that cozy futurism is a subset of solarpunk, and that one could imagine multiple cozily futuristic ideologies or aesthetics, solarpunk being one.  ^386238684
> > [!note] Note
> > 
> > 

