Full Title: Local News Will Come to Rely on AI
Author: [[Bill Grueskin]]
Category: articles
Document Tags: [[Journalism MOC]] [[Technology MOC]] 
URL: https://www.niemanlab.org/2022/12/local-news-will-come-to-rely-on-ai/

## Highlights & Notes
> [!quote] Highlight
>  I predict that editors at struggling metro dailies, or thinly staffed nonprofits that are charged with covering government bodies, will someday look at this as a boon. Local newspapers and sites are getting thin these days. It isn’t just that they’re not publishing as many Pulitzer-finalist series as they used to. They also aren’t covering as many school boards, legislative committees, real-estate sales, new-business openings, and the rest of the grist that used to fill the back pages of newspapers. Even obituaries are largely relegated to paid notices from relatives. And as this information dries up, citizens feel more estranged from the agencies that govern their lives and the officials who set their tax rates and hire their superintendents.  ^441060804
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  There’s good reason for this news deficit. After the budget-trimmers have left you reeling, you’re not going to have one of your remaining reporters mindlessly type in city-commission minutes when they could be out covering news. But if we can automate some of this commodity news, we can provide a lot more information — much of it useful, if not sexy — to people who need it.  ^441060787
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The bigger pitfall is the garbage-in, garbage-out problem. You can’t simply tell an AI program, “What did the town council do today?” or “Who got arrested last week?” You have to supply it with some raw information.  ^441060775
> > [!note] Note
> > 
> > 

