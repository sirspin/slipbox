Full Title: Are you serious?
Author: [[Visakan Veerasamy]]
Category: articles
URL: https://visakanv.substack.com/p/are-you-serious
Tags: [[Sociology MOC]]

## Highlights & Notes
> [!quote] Highlight
>  We do live in a world that’s full of unserious people.  ^472559107
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Anybody can say that they’re serious. How can I demonstrate that I’m serious?  ^472561262
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  When I say serious I don’t mean solemn and tedious. I mean something closer to ‘[[Dynamic Persistence]]’,  ^472561263
> > [!note] Note
> > 
> > 

