Full Title: Why muddy puddles are actually good for children
Author: [[Alessia Franco]]
Category: articles
Document Tags: [[Health MOC]] 
URL: https://www.bbc.com/future/article/20220929-how-outdoor-play-boosts-kids-immune-systems

## Highlights & Notes
> [!quote] Highlight
>  According to recent research, the dirt outside is teaming with friendly microorganisms that can train the immune system and build resilience to a range of illnesses, including allergies, asthma and even depression and anxiety.  ^399786606
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  These findings show that outdoor exercise is not only beneficial because of the chance to roam free – but that certain natural materials, such as soil and mud, also contain surprisingly powerful microorganisms whose positive impact on children's health we are only beginning to fully understand.  ^399786607
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Various studies support this idea. People who grow up on farms are generally less likely to develop asthma, allergies, or auto-immune disorders like Crohn's disease – thanks, apparently, to their childhood exposure to a more diverse range of organisms in the rural environment that had encouraged more effective regulation of the immune system.  ^399787732
> > [!note] Note
> > Nature is not just emotionally healthy, it's physically healthy too. Sterilizing our lives will only have a negative effect.
> > 

