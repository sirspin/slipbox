URL: [https://walkingtheworld.substack.com/p/walking-dakar-part-2](https://walkingtheworld.substack.com/p/walking-dakar-part-2)
Author: [[Chris Arnade]]
Publisher: [[Walking The World]]
Published Date: 2023-06-20
Tags: [[Travel MOC]] [[Sociology MOC]]

## Highlights
> [!quote] Highlight
> I’ve written a lot about how many of the places I’ve visited, even poorer places like Hanoi, actually have it good compared to the US. Not in material terms, but in the sense of residents who are happy, content, and deeply fulfilled because their life isn’t just about the material.
> > > [!quote] Highlight
> I run a thought experiment in my head: If a resident of X could push a button and immediately be given a working class or middle class life in the US, would and should they?
> > > [!quote] Highlight
> It’s this accounting trade off — is the material gain worth the spiritual loss — that I think a lot about when addressing the second part of my thought experiment, “should someone push the ‘move to the US button'?’”
> > > [!quote] Highlight
> Dakar sucks, and it looks like it will keep sucking for the foreseeable future. The bulk of my cynicism comes from my last eight days walking Dakar, but some of it also comes from seeing who’s both hyping Africa’s future while hyping their solutions to its current problems: the global non-profit industry, including firms and people who have never set foot in Africa, outside of some conferences in a convention center.
> > > [!quote] Highlight
> the whole, “we aren’t out to make money, only to help you” thing of the non-profit industry is somehow worse. Because it’s a lie and a scam.
> > > [!quote] Highlight
> Senegal needs a lot of things, but they don’t need more advice from an of out-of-touch policy class with no skin in the game, no commitment to the place, beyond what helps them builds their own resume and status, and a few more $5,000 junkets to Africa.
> > > [!quote] Highlight
> What they really need is to be left alone to do their own thing, as they want to do it. Not to be played with as the “thing of the moment” for bored technocrats looking to technocrat.
> > > > [!note] Note
> > A bit unempathetic?
