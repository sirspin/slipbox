Full Title: Notes on “Taste”
Author: [[Brie Wolfson]]
Category: articles
Document Tags: [[Aesthetics MOC]] [[Life Design MOC]] [[Philosophy MOC]] 
URL: https://www.are.na/blog/notes-on-taste

## Highlights & Notes
> [!quote] Highlight
>  10. While taste is often focused on a single thing, it is often formed through the integration of diverse, and wide-ranging inputs.  ^411685890
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  taste is a mode. It’s a manner of interpretation, expression, or action.  ^411685732
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Appreciation is a form of taste. Creation is another. They are often intertwined, but don’t have to be.  ^411685733
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Someone could have impeccable taste in art, without producing any themselves. Those who create tasteful things are almost always deep appreciators, though.  ^411685734
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  There are degrees of taste, but we typically talk about it in binaries. One can have taste or not. Great taste means almost the same thing as taste.  ^411685775
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  taste isn’t often outgrown.  ^411685776
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  taste tends to develop very unevenly. It's rare that the same person has good visual taste and good taste in people and taste in ideas.” The sought-after interior designer may not mind gas station coffee. The prolific composer may not give a damn about how they dress.  ^411685809
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  To have taste is to be persnickety and one doesn’t want to be persnickety or annoyed about too many things.  ^411685891
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Irony and satire are frenemies of taste.  ^411685892
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  “‘Good taste' is simply to have a well formed opinion, in accordance with the realities of the Good and the True.”  ^411685893
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Taste is not the same as correctness, though.  ^411685894
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  [[Taste]] gets you to the thing that’s more than just correct. Taste hits different. It intrigues. It compels. It moves. It enchants. It fascinates. It seduces.  ^411685895
> > [!note] Note
> > Cultivating taste should be a noble pursuit for all
> > 

> [!quote] Highlight
>  Taste requires originality. It invokes an aspirational authenticity. Writer [[George Saunders]] calls this “achieving the [[iconic space]],” and it’s what he’s after when he meets his creative writing students. “They arrive already wonderful. What we try to do over the next three years is help them achieve what I call their “[[iconic space]]” — the place from which they will write the stories only they could write, using what makes them uniquely themselves…At this level, good writing is assumed; the goal is to help them acquire the technical means to become defiantly and joyfully themselves.”  ^411690057
> > [!note] Note
> > What is my [[iconic space]]?
> > 

> [!quote] Highlight
>  Another framing for this is “turpentine.” It comes from Picasso remarking that “when art critics get together they talk about Form and Structure and Meaning. When artists get together they talk about where you can buy cheap turpentine.” Taste rests on turpentine.  ^411690058
> > [!note] Note
> > Art isn't birthed from talking about art, but in the absence of *your* art.
> > 

> [!quote] Highlight
>  Be patient, the process of metabolizing the world is a slow one. Wield your P/N meter well, take your time learning what you find compelling, and why.  ^411690059
> > [!note] Note
> > 
> > 

