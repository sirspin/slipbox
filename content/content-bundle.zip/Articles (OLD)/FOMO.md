Full Title: FOMO
Author: [[Jack Raines]]
Category: articles
Document Tags: [[Life Design MOC]] [[Psychology MOC]] 
URL: https://www.youngmoney.co/p/fomo

## Highlights & Notes
> [!quote] Highlight
>  FOMO doesn't care about rationality. It thrives on irrationality.  ^388576324
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  FOMO, if not resisted, leads to losses. Social FOMO steals all of your time. Investment FOMO incinerates all of your money. Career FOMO destroys all of your focus.  ^388576325
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  a high susceptibility to FOMO will decrease the success that created your FOMO in the first place, as your attention and energy are spread too thin.  ^388576326
> > [!note] Note
> > 
> > 

