Full Title: William Shatner: My Trip to Space Filled Me With ‘Overwhelming Sadness’
Author: [[Andy Baio]]
Category: articles
Document Tags: [[Life Design MOC]] [[Philosophy MOC]] 
URL: https://variety.com/2022/tv/news/william-shatner-space-boldly-go-excerpt-1235395113/

## Highlights & Notes
> [!quote] Highlight
>  I had a different experience, because I discovered that the beauty isn’t out there, it’s down here, with all of us. Leaving that behind made my connection to our tiny planet even more profound.  ^395749104
> > [!note] Note
> > The grass is always greener, except when you're not on Earth.
> > 

> [!quote] Highlight
>  It was among the strongest feelings of grief I have ever encountered.  ^395749106
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The contrast between the vicious coldness of space and the warm nurturing of Earth below filled me with overwhelming sadness. Every day, we are confronted with the knowledge of further destruction of Earth at our hands: the extinction of animal species, of flora and fauna . . . things that took five billion years to evolve, and suddenly we will never see them again because of the interference of mankind. It filled me with dread.  ^395749115
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  My trip to space was supposed to be a celebration; instead, it felt like a funeral.  ^395749116
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  I learned later that I was not alone in this feeling. It is called the “Overview Effect” and is not uncommon among astronauts, including Yuri Gagarin, Michael Collins, Sally Ride, and many others. Essentially, when someone travels to space and views Earth from orbit, a sense of the planet’s fragility takes hold in an ineffable, instinctive manner.  ^395749120
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  In this insignificance we share, we have one gift that other species perhaps do not: we are aware—not only of our insignificance, but the grandeur around us that makes us insignificant. That allows us perhaps a chance to rededicate ourselves to our planet, to each other, to life and love all around us. If we seize that chance.  ^395749140
> > [!note] Note
> > 
> > 

