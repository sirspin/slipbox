Full Title: The Start of Every Phone Call Is Technological Torture
Author: [[Ian Bogost]]
Category: articles
Document Tags: [[Sociology MOC]] [[Technology MOC]] 
URL: https://www.theatlantic.com/technology/archive/2022/10/phone-call-greeting-smartphone-technological-error/671910/

## Highlights & Notes
> [!quote] Highlight
>  Technology is a condition.  ^414287205
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Nothing really works, and nothing is truly broken either, but instead these miraculous machines we invented take on their own lives alongside us.  ^414287206
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  that distress is also a comfort, for it offers a common murk in which each of us gropes for a handhold so as not to be consumed.  ^414287207
> > [!note] Note
> > 
> > 

