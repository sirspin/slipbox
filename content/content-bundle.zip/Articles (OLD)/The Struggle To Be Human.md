Full Title: The Struggle To Be Human
Author: [[Ian Leslie]]
Category: articles
Document Tags: [[Technology MOC]] [[Writing MOC]] 
URL: https://ianleslie.substack.com/p/the-struggle-to-be-human

## Highlights & Notes
> [!quote] Highlight
>  Here’s the thing: ChatGPT is casting a light on the problem of bullshit writing by humans.  ^438988622
> > [!note] Note
> > 
> > 

