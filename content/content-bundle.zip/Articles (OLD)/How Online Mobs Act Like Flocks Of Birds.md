Full Title: How Online Mobs Act Like Flocks Of Birds
Author: [[Renee DiResta]]
Category: articles
URL: https://www.noemamag.com/how-online-mobs-act-like-flocks-of-birds
Tags: [[Sociology MOC]] [[Communication MOC]]

## Highlights & Notes
> [!quote] Highlight
>  While much is still mysterious and debated about the workings of murmurations, computational biologists and computer scientists who study them describe what is happening as “the rapid transmission of local behavioral response to neighbors.”  ^468054324
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  growing body of research suggests that human behavior on social media — coordinated activism, information cascades, harassment mobs — bears striking similarity to this kind of so-called “emergent behavior” in nature:  ^468054325
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  how one bird follows another, how I retweet you and you retweet me — is also determined by the structure of the network.  ^468054326
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  signals are passed from screen to screen, news feed to news feed, along an artificial superstructure designed by humans but increasingly mediated by at-times-unpredictable algorithms. It is curation algorithms, for example, that choose what content or users appear in your feed; the algorithm determines the seven birds, and you react.  ^468054327
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Once people had exhaustively connected with their real-world friend networks, the platforms were financially incentivized to help them find whole new flocks in order to maximize the time they spent engaged on site. Time on site meant a user was available to be served more ads; activity on site enabled the gathering of more data, the better to infer a user’s preferences in order to serve them just the right content — and the right ads.  ^468054328
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The system, the infrastructure itself, shaped society, which shaped behavior, which shaped society. The programming — the substance, the content — was somewhat secondary.  ^468054488
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  In an information-rich world, the wealth of information means a dearth of something else: a scarcity of whatever it is that information consumes. What information consumes is rather obvious: it consumes the attention of its recipients. Hence a wealth of information creates a poverty of attention and a need to allocate that attention efficiently among the overabundance of information sources that might consume it.  ^468054533
> > [!note] Note
> > 
> > 

