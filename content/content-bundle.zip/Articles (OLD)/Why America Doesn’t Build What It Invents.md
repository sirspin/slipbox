Full Title: Why America Doesn’t Build What It Invents
Author: [[Derek Thompson]]
Category: articles
Document Tags: [[Sociology MOC]] [[Technology MOC]] 
URL: https://www.theatlantic.com/newsletters/archive/2022/12/us-progress-scientific-breakthrough-implementation-nuclear-fusion/672484/

## Highlights & Notes
> [!quote] Highlight
>  progress is as much about implementation as it is about invention.  ^437000420
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  the way that individuals and institutions take an idea from one to 1 billion is the real story of progress.  ^437000421
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  Inspired by the success of the government program to accelerate the development of the COVID vaccines, what would an Operation Warp Speed for cancer prevention look like?  ^437004142
> > [!note] Note
> > 
> > 

