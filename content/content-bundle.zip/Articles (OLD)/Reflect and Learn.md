URL: [https://getmatter.com/email/26421669/?token=26421669%3A6YcF1gSSMVYuEIINOMRPc2foHmE](https://getmatter.com/email/26421669/?token=26421669%3A6YcF1gSSMVYuEIINOMRPc2foHmE)
Author: [[Stowe Boyd]]
Publisher: [[www.workfutures.io]]
Published Date: 2023-06-18
Top Note: Lessons from [[Ross Dawson]] on preparing for future work / the future
Tags: [[Learning MOC]], [[Worklife MOC]]

## Highlights
> [!quote] Highlight
> Take the time to plan your future. We all need to be our own futurists. In a busy world, we must carve out proper time to consider how our skills and our dreams will fit with an economy that is swiftly changing. We must work today to prepare ourselves for the jobs and opportunities of the future, transitioning from our past career to our future careers.
> > [!quote] Highlight
> Carefully choose your expertise. Our livelihood tomorrow will be shaped by what we study today. To stand out, we should aim to excel at one or two specific areas of work, at which we can become an ‘expert’. It is important to follow your passion, but also to consider whether the skills you are developing will still be valuable in 5, 10 or 20 years’ time.
> > [!quote] Highlight
> Fuel your appetite for learning. We all need to keep learning throughout our lives to keep ahead in this fast-changing world. Rather than this feeling like a chore, we need to make learning something we want to do. Discover what you most want to learn about, and design it to be as fun and social as you can.
> > [!quote] Highlight
> But there is a subtle toe-stub when he enlarges this to the enterprise: Envisage your successful future organisation. Today’s companies will fail if they simply try to eliminate some jobs and add others. Every single work role will change in the future, shifting to draw more on uniquely human capabilities. Becoming tomorrow’s successful organisation requires a clear vision of the skills and roles you will require, and planning how to transition your current team from where they are to where they need to be.
> 