Full Title: Time Isn't Money
Author: [[Jack Raines]]
Category: articles
Document Tags: [[Life Design MOC]] 
URL: https://www.youngmoney.co/p/time-isnt-money-b288

## Highlights & Notes
> [!quote] Highlight
>  Some luxuries won't make your life any better, but losing them after having experienced them will certainly make your life worse. - Nassim Taleb  ^385342591
> > [!note] Note
> > Set your expectations early and your limits often.
> > 

> [!quote] Highlight
>  Money is infinite, time is finite. These are the two rules of the game. To maximize your satisfaction from the game, you need to know how much money is enough, you need to make money without sacrificing time, and you need to be able to afford the experiences that you want in life.  ^385342592
> > [!note] Note
> > More money is not always the answer!
> > 

