Full Title: The Crane Wife
Author: [[CJ Hauser]]
Category: articles
Document Tags: [[Science MOC]] [[Sociology MOC]] [[Writing MOC]] 
URL: https://www.theparisreview.org/blog/2019/07/16/the-crane-wife/

## Highlights & Notes
> [!quote] Highlight
>  I went to Texas to study the whooping crane because I was researching a novel. In my novel there were biologists doing field research about birds and I had no idea what field research actually looked like and so the scientists in my novel draft did things like shuffle around great stacks of papers and frown. The good people of the Earthwatch organization assured me I was welcome on the trip and would get to participate in “real science” during my time on the gulf. But as I waited to be picked up by my team in Corpus Christi, I was nervous—I imagined everyone else would be a scientist or a birder and have daunting binoculars.  ^385342593
> > [!note] Note
> > 
> > 

