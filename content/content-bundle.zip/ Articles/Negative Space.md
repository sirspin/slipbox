URL: https://getmatter.com/email/29156806/?token=29156806%3AOe5EdpFl7olu_Dxo-r0jV0ptr0g
Author: [[Ed Zitron]]
Date: [[08-10-2023]]
Tags: [[Worklife MOC]] 


## Highlights
<br>

>[!quote]
>My anecdotal sense about the remote work debate — at least within the tech industry — is that despite it arguably creating better outputs, something about it felt icky to tech’s elite.<br>
>>[!note]
>>
</p><br>

>[!quote]
>tech’s loudest assholes have been crying for a “great reset,” realizing that workers had accumulated too much power, flexibility, and leverage (a more palatable explanation than the fact that big tech companies used their massive post-pandemic gains to overhire people) and that something had to change.<br>
>>[!note]
>>
</p><br>

>[!quote]
>What’s actually happening is that the tech industry — and possibly the economy at large — desperately wants to return to the pre-pandemic world. Venture capitalists are sitting on over $270 billion of uninvested capital, yet claim that’s a result of a “market reset” rather than the “new market realities” caused by the very same venture capitalists that invested billions of dollars in non-companies.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Venture capital is mourning the death of a world where happy accidents were interpreted as strokes of genius, and where every idea that they pumped money into became a valuable company through association and a wire transfer.<br>
>>[!note]
>>
</p>