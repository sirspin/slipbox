URL: https://www.robinrendle.com/notes/moving-is-not-failure/
Author: [[Robin Rendle]]
Date: [[11-22-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>“Moving always feels like failure,” a friend told me a few days ago. And it’s true. You can’t help but feel that this place was your place, the only place you could ever be. It’s as if you’re throwing away all this...something...only to replace it with something else that might not be as special. Something that might not be yours. It feels disrespectful to all those memories of sunsets and sunrises and giggles in the hallway. Moving into a new place feels like cheating.<br>
>>[!note]
>>
</p><br>

>[!quote]
>But the more we pack, the less attached we are. We slowly realize that this home wasn’t important because of the valley outside, or the way that light trickled in, or the kind neighbors who held our packages for us. It wasn’t important because of the big windows or the long hallway or the snugness of my office in winter. It was only important because we were briefly here. And now we’ll make somewhere else important; we’ll build it up, move in all our stuff, and over time I’m sure that we’ll make it just as snug, just as important as this place was. We’ll take our giggles and tears and even brighter sunsets too and we’ll move them into another corner of San Francisco that we can call our own.<br>
>>[!note]
>>
</p><br>

>[!quote]
>And then, I’m certain, it won’t feel like failure.<br>
>>[!note]
>>
</p>