URL: https://www.worksinprogress.co/issue/the-housing-theory-of-everything/
Author: [[Ben Southwood]]
Date: [[09-14-2021]]
Tags: [[Life Design MOC]]


## Highlights
<br>

>[!quote]
>The obvious effect of expensive housing – people having less money to spend on other things – is the one most people focus on. But it is only part of the story, because expensive housing makes people change their behaviour too<br>
>>[!note]
>>
</p><br>

>[!quote]
>According to one study, if just three cities – New York City, San Jose and San Francisco – loosened their rules against building denser housing to the national average level of restrictiveness, millions would move to jobs that made the best use of their skills and total US GDP would be 8.9% higher.<br>
>>[!note]
>>
</p><br>

>[!quote]
>This housing affordability problem has become much worse over the past four decades – coinciding with, and partly driven by, the growth of the intangible economy — the move towards production based on software and intellectual property, instead of machinery and other physical capital.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Some kind of creative, below-the-radar solution that turns this zero-sum game into a positive-sum one is likely to have a better chance. In a tug of war, it’s often surprising how far you can go if you tug the rope sideways.<br>
>>[!note]
>>
</p><br>

>[!quote]
>we’re right about this, it means that fixing this one problem could make everyone’s lives much better than almost anyone realises – not just by making houses cheaper, but giving people better jobs, a better quality of life, more cohesive communities, bigger families and healthier lives. It could even give renewed reasons to be optimistic about the future of the West.<br>
>>[!note]
>>
</p><br>

>[!quote]
>What matters is that housing shortages may be the biggest problem facing our era, and solving it needs to become everyone’s highest priority.<br>
>>[!note]
>>
</p><br>

>[!quote]
>By contrast, almost every other household product has become better and less expensive since then. Compared to 1975, the number of hours a median American worker would have to work to buy a television fell from 60 hours in 1975 to 7 hours in 2013; to buy a fridge-freezer, it fell from 65 hours in 1975 to 20 hours in 2013; to buy a manual exercise treadmill, from 18 hours in 1975 to 6 hours in 2013; and to buy a washer-dryer, from 67 to 30 hours. Even cars are three times ‘cheaper’ in terms of hours worked on an average hourly wage now than they were in 1964.<br>
>>[!note]
>>
</p><br>

>[!quote]
>prices range from about twice to four times the cost of building new homes of equivalent specification. This wedge, between build costs and house prices, is a rough proxy for how much extra cost is being driven by restrictions on new building.<br>
>>[!note]
>>
</p><br>

>[!quote]
>many people are working in less productive jobs than they could if it was easier for them to move to more productive places.<br>
>>[!note]
>>
</p><br>

>[!quote]
>people who do get to live in these high-productivity places are less productive than they could be, because they are less able to combine their skills with the complementary skills of the people who have been priced out.<br>
>>[!note]
>>
</p><br>

>[!quote]
>In the United States, productivity per worker tends to rise by 2% or more with each doubling of city size.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The link between size and productivity is only apparent when the city includes skilled, educated workers, which suggests the effect is mostly driven by the transfer of knowledge and division of labour among high-skilled workers. Metropolitan areas that are largely made up of unskilled workers do not become more productive as they get bigger.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Bell Labs, the legendary R&D lab that invented revolutionary new technologies like the transistor and the photovoltaic cell, was designed so that everyone would at some point bump into everyone else for this reason.<br>
>>[!note]
>>Proximity theory!
</p><br>

>[!quote]
>Once you see the effects housing shortages have on things as wildly different as obesity, fertility, inequality, climate change and wage growth, you start to see them everywhere.<br>
>>[!note]
>>
</p><br>

>[!quote]
>have suggested one possibility elsewhere: radically localized democracy that allows individual streets to opt in to greater density by voting for it. No construction would happen anywhere that a majority did not opt for it, but streets that voted for more density would become extremely valuable, so there would be a big incentive for homeowners in high-demand areas to vote for greater density.<br>
>>[!note]
>>
</p>