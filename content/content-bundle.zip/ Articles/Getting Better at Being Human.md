URL: https://getmatter.com/email/26000974/?token=26000974%3Auhr9v5lyKDQBq29LGEuBsPV5R0E
Author: [[David Cain]]
Date: [[06-12-2023]]
Tags: [[Worklife MOC]] [[Writing MOC]] 

>[!tip]
>Good tip for [[Biz Plan]]


## Highlights
<br>

>[!quote]
>If you try to address everyone’s problems, you can’t compete with those who specialize.<br>
>>[!note]
>>
</p><br>

>[!quote]
>“Getting better at being human” is one the broadest topics imaginable. Humans do all sorts of things. Getting better at cooking omelets, or lying on the couch, could certainly count as “getting better at being human,” as could learning to make friends as an adult, recognizing beauty in the mundane, coping with self-destructive tendencies, staying sane in the too-much-information age, and ten thousand other things. Each of these concerns could be a niche one might specialize in.<br>
>>[!note]
>>
</p><br>

>[!quote]
>When I ask people why they subscribe to this site, trying to tease out common concerns I might help the readership with, they always say “I just like the way you think! Keep it up!” or “You say things I was thinking but didn’t know how to say.”<br>
>>[!note]
>>Tip for Writing MOC
</p>