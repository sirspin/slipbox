URL: https://moretothat.com/burnout-is-the-echo-of-self-judgment/
Author: [[Lawrence Yeo]]
Date: [[06-06-2023]]
Tags: [[Psychology MOC]] [[Sociology MOC]] [[Worklife MOC]] 


## Highlights
<br>

>[!quote]
>burnout is entirely the result of inner exploitation.<br>
>>[!note]
>>
</p><br>

>[!quote]
>in the quest to pursue this freedom, you will end up chaining yourself to the value you produce for others.<br>
>>[!note]
>>
</p><br>

>[!quote]
>After all, if money is what buys freedom, you need to ensure that you’re being useful enough to get paid in the first place.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Freedom is the great promise of capitalism, but it has also enshrined productivity as a virtue in order to achieve that aim.<br>
>>[!note]
>>
</p><br>

>[!quote]
>No external boss will be needed for you to get to work, as your inner critic will always remind you that there’s more to be done. This dynamic is what is referred to as self-exploitation,<br>
>>[!note]
>>
</p><br>

>[!quote]
>While the ubiquity of money and the desire for freedom are fixed variables, the belief of how valuable we must be to others is variable and can therefore be adjusted.<br>
>>[!note]
>>
</p><br>

>[!quote]
>realizing that your identity is distributed across many areas, you can approach your work identity with a lightheartedness knowing that it doesn’t define the entirety of who you are.<br>
>>[!note]
>>
</p>