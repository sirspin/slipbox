URL: https://fee.org/resources/i-pencil/
Author: [[Leonard E. Read]]
Date: [[01-01-1958]]
Tags: [[Philosophy MOC]] [[Sociology MOC]] 


## Highlights
<br>

>[!quote]
>This is a species of the grievous error in which mankind cannot too long persist without peril. For, the wise G. K. Chesterton observed, “We are perishing for want of wonder, not for want of wonders.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>The absence of a master mind, of anyone dictating or forcibly directing these countless actions which bring me into being. No trace of such a person can be found. Instead, we find the Invisible Hand at work. This is the mystery to which I earlier referred.<br>
>>[!note]
>>Concept of the [[Invisible Hand]] to describe the societal collaboration and machinery of collective human engineering
</p><br>

>[!quote]
>in the absence of faith in free people—in the unawareness that millions of tiny know-hows would naturally and miraculously form and cooperate to satisfy this necessity—the individual cannot help but reach the erroneous conclusion that mail can be delivered only by governmental “masterminding.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>The lesson I have to teach is this: Leave all creative energies uninhibited. Merely organize society to act in harmony with this lesson. Let society’s legal apparatus remove all obstacles the best it can. Permit these creative know-hows freely to flow. Have faith that free men and women will respond to the Invisible Hand. This faith will be confirmed. I, Pencil, seemingly simple though I am, offer the miracle of my creation as testimony that this is a practical faith, as practical as the sun, the rain, a cedar tree, the good earth.<br>
>>[!note]
>>
</p>