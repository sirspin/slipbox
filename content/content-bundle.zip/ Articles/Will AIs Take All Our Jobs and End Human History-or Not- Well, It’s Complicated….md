URL: https://writings.stephenwolfram.com/2023/03/will-ais-take-all-our-jobs-and-end-human-history-or-not-well-its-complicated/
Author: [[Stephen Wolfram]]
Date: [[03-15-2023]]
Tags: [[Sociology MOC]] [[Technology MOC]] [[Worklife MOC]] 


## Highlights
<br>

>[!quote]
>from AIs. I should say at the outset that this is a subject fraught with both intellectual and practical difficulty. And all I’ll be able to do here is give a snapshot of my current thinking—which will inevitably be incomplete—not least because, as I’ll discuss, trying to predict how history in an area like this will unfold is<br>
>>[!note]
>>
</p>