URL: https://theconvivialsociety.substack.com/p/the-pathologies-of-the-attention
Author: [[L.M. Sacasas]]
Date: [[09-26-2022]]
Tags: [[Technology MOC]] [[Psychology MOC]] [[Communication MOC]]


## Highlights
<br>

>[!quote]
>“Ours is not truly an information economy,” Goldhaber claimed. “Economics,” he went on to explain, is the study of how a society uses its scarce resources. And information is not scarce—especially on the Net, where it is not only abundant, but overflowing. We are drowning in information, yet constantly increasing our generation of it. So a key question arises: Is there something else that flows through cyberspace, something that is scarce and desirable? There is. No one would put anything on the Internet without the hope of obtaining some. It's called attention. And the economy of attention—not information—is the natural economy of cyberspace.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>Shifts from scarcity to abundance radically alter whatever natural or social landscape we happen to be considering. For example, many of the debates about journalism often fail to reckon with the basic fact of information superabundance.)<br>
>>[!note]
>>
</p><br>

>[!quote]
>Citton introduced me to the work of Gabriel Tarde, a French sociologist who died in 1904. Two years before his death, Tarde published Economic Psychology, which anticipated the dynamics of what we know as the attention economy.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Tarde understood immediately […] the extent to which advertising, necessary for the absorption of excess goods coming from industrial overproduction, needed to be considered in terms of attention: ‘Interrupting attention, fixing it on the thing being proffered, is the immediate and direct effect of advertising.’ He sensed perfectly the contagious implications of this: ‘it is not just the fourth page of newspapers that is made up of advertisements. The whole body of the paper is a one big continuous and general advertisement.’<br>
>>[!note]
>>
</p><br>

>[!quote]
>‘The need for a fameometer becomes even more apparent when celebrities of every kind are more abundant, more sudden and more fleeting, and when, despite their habitual impermanence, they do not fail to be accompanied by a formidable power, since they are a good for the possessor, but a light, a faith, for society.’<br>
>>[!note]
>>
</p><br>

>[!quote]
>I would describe the pattern this way: 1. We inhabit a techno-social environment manufactured to fracture our attention. 2. The interests served by this environment in turn pathologize the resultant inattention. 3. These same interests devise and enforce new techniques to discipline the inattentive subject.<br>
>>[!note]
>>
</p>