URL: https://www.theatlantic.com/newsletters/archive/2022/09/what-america-doesnt-understand-about-teachers-and-professors/671590/
Author: [[Derek Thompson]]
Date: [[09-29-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>“Undergraduate teaching is the backbone of most universities, yet at institutions like the one at which I work there is no reward for quality teaching.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>We talk about and reward teachers as becoming better at their craft the older their students are. College professors … make more money. But anyone who actually works in education knows that elementary teachers are, pound-for-pound, the best at what [they] do. First grade teachers move mountains everyday. Fourth grade teachers would make our best cult leaders if they weren’t justifiably exhausted all the time.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Perhaps the most bizarre and borderline-exploitative part of the work is that today’s professors often write free articles for academic journals that they have to pay to access. “When we write articles for academic journals, we are not paid for the articles,” said Caitie, an associate professor.<br>
>>[!note]
>>
</p>