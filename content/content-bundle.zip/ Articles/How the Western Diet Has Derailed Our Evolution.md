URL: https://nautil.us/how-the-western-diet-has-derailed-our-evolution-235683/
Author: [[Moises Velasquez-Manoff]]
Date: [[11-10-2015]]
Tags: 


## Highlights
<br>

>[!quote]
>The Western microbiome, the community of microbes scientists thought of as “normal” and “healthy,” the one they used as a baseline against which to compare “diseased” microbiomes, might be considerably different than the community that prevailed during most of human evolution.<br>
>>[!note]
>>
</p>