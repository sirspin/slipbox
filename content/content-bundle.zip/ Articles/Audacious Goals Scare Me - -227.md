URL: https://getmatter.com/email/26421671/?token=26421671%3Au8OpuQN5_R84_0WTpfvZZE4Hx3g
Author: [[Paul Millerd]]
Date: [[06-17-2023]]
Tags: [[Philosophy MOC]] [[Psychology MOC]] [[Worklife MOC]] 

>[!tip]
>Intro to Paul's work


## Highlights
<br>

>[!quote]
>In my jobs, managers told me I needed to “self-promote” more if I wanted to get promoted. I rarely followed this advice and instead focused on trying to do good work and getting raises and promotions by changing jobs every year and a half. On my current path, I’ve called my approach the long, slow, stupid, fun way.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Long: Focus on the meta-game of finding the work I want to keep doing indefinitely. Don’t get distracted by shiny objects. Slow: Do things slowly. Start small and level up over time. Stupid: Lean against obvious ways to make more money when you sense it’s not the thing that will matter over the long run. Fun: Am I still having fun? Keep going. If not, quit, optimize, or scale back..<br>
>>[!note]
>>
</p><br>

>[!quote]
>From 2018 to 2021, I operated in monk mode, staying purposefully small, explicitly rejecting anything that looked like a status or attention game and focused on exploring new ways of working and designing my life. One of the most impactful things I did during those years ended up being my attempt to adopt an anti-strategy of rejecting the popular advice to “protect your calendar” and opening up my calendar for curiosity conversations every Wednesday to anyone that wanted to talk with me.<br>
>>[!note]
>>
</p>