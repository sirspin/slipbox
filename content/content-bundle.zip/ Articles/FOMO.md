URL: https://www.youngmoney.co/p/fomo
Author: [[Young Money - Jack]]
Date: [[09-20-2022]]
Tags: [[Psychology MOC]]


## Highlights
<br>

>[!quote]
>FOMO doesn't care about rationality. It thrives on irrationality.<br>
>>[!note]
>>
</p><br>

>[!quote]
>FOMO, if not resisted, leads to losses. Social FOMO steals all of your time. Investment FOMO incinerates all of your money. Career FOMO destroys all of your focus.<br>
>>[!note]
>>
</p><br>

>[!quote]
>a high susceptibility to FOMO will decrease the success that created your FOMO in the first place, as your attention and energy are spread too thin.<br>
>>[!note]
>>
</p>