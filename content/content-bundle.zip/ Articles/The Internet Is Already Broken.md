URL: https://getmatter.com/email/26421653/?token=26421653%3AjLivEyqWEGIDUoOt2y6oodIVAOs
Author: [[Ed Zitron]]
Date: [[06-20-2023]]
Tags: [[Communication MOC]] [[Journalism MOC]] [[Sociology MOC]] [[Technology MOC]] 


## Highlights
<br>

>[!quote]
>Email has become the victim of the late-stage capitalist internet – a place where we are continually productized and monetized, where our actions are evaluated to better market us products, and where the actual experience of using said products too often exists to find more efficient ways to get our cash.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Some of us might occasionally jump a wall and surprise those experimenting on us, but as it stands, the internet has become a kleptocratic playground for billionaires to monetize our every move.<br>
>>[!note]
>>
</p>