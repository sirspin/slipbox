URL: https://reutersinstitute.politics.ox.ac.uk/news-powerful-and-privileged-how-misrepresentation-and-underrepresentation-disadvantaged
Author: [[Amy Ross Arguedas]]
Date: [[04-18-2023]]
Tags: [[Journalism MOC]] 


## Highlights
<br>

>[!quote]
>Privileged audiences may be concerned about, say, sensationalism, but they rarely pay a personal price. Disadvantaged communities do.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The lens through which many saw the failings of the news media in their countries was in large part (although not only) related to problems they saw in how people like them were portrayed in the media. And while some groups articulated complaints in similar ways as other audiences when it came to concerns about misrepresentation, underrepresentation, and perceived inaccuracies in coverage, the examples they offered often made clear the extent to which frustrations with news were not simply reasons to distrust it, but sources of palpable harm to communities already disadvantaged in society.<br>
>>[!note]
>>
</p>