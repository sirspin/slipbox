URL: https://every.to/feeds/45fc42fd28eeaf4b0816/devote-yourself-to-the-cause-of-your-life
Author: [[Evan Armstrong]]
Date: [[08-03-2023]]
Tags: [[Life Design MOC]] [[Philosophy MOC]] 


## Highlights
<br>

>[!quote]
>What I am arguing is that there is a better way of working. This is my case for what I call the builder’s state of being: when you revel in the day-to-day minutia, the tedious tasks that make up your job.<br>
>>[!note]
>>
</p><br>

>[!quote]
>When we focus excessively on productivity, when our biggest concern is on how to “scale ourselves,” we miss the point of work—and, really, life—which is to find meaning in the daily tasks that consume our time.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Like a bike chain catching a gear, there is a deeply satisfying *cachunk* that happens in your brain when you go from enjoying the outcome of your labors to enjoying the process of them.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Unfortunately, and predictably, readers tended to gloss over the philosophical implications.<br>
>>[!note]
>>What are the philosophical implications of self-help vis a vis “personal knowledge management” or productivity? What does it say about our quality of life and living?
</p><br>

>[!quote]
>Instead, the idea of only working four hours a week is what hooked consumers. It spun up an entire industry of online hustle culture hucksters who fashioned themselves into internet-native intellectual bourgeoisie.<br>
>>[!note]
>>There is a balance here #seed - the idea that there’s a middle ground between what [[Bertrand Russell]] describes as leisure and the philosophical pursuit that is joy of building and the joy of life’s work. You can’t minimize one away without losing a key piece
</p><br>

>[!quote]
>There is a reason these people have to fill themselves with Athletic Greens and do cold plunges just so they can feel something.<br>
>>[!note]
>>
</p><br>

>[!quote]
>this point, if you haven’t thought of multiple ways I’m wrong, you’re not engaging deeply enough with the argument. I am aware that poverty exists. I am aware that I shouldn’t judge how people try to escape the 9-to-5 grind. I am aware that a job’s purpose is money, not emotional enrichment.<br>
>>[!note]
>>Maybe she’s wrong in many ways, but the ability for ALL people to seek and find pleasure in their daily building should be a human fundamental right. Barriers to this are what keep populations in bad spots.
</p><br>

>[!quote]
>What I am instead arguing for is something more expansive. The thing you should work hard at is everything. Finding ways to imbue each moment with meaning and purpose and effort is the only path to long-term happiness. You must devote yourself to the cause of your life.<br>
>>[!note]
>>But what does this MEAN? It’s self-exploration. It’s [[Testimony]]
</p>