URL: https://clip.demochen.com/2022/12/04/thinking-together/index.html
Author: [[Gordon Brander]]
Date: [[11-07-2022]]
Tags: [[Psychology MOC]]


## Highlights
<br>

>[!quote]
>Philosopher Paul Tillich posits that when social sensemaking fails to keep up with reality, we experience it as a kind of mass neurosis. Everybody has a crisis of meaning at the same time. Life stops making sense. Anyone living through 2016 onward knows that feeling. The Permaweird.<br>
>>[!note]
>>
</p><br>

>[!quote]
>As our problems get more complex, our ability to meaningfully coordinate breaks down.<br>
>>[!note]
>>
</p>