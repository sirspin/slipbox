URL: https://www.nytimes.com/2022/11/30/opinion/covid-pandemic-cities-future.html
Author: [[Thomas B. Edsall]]
Date: [[11-30-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>Despite his optimism, Florida acknowledged in his email that American cities are uniquely vulnerable to social disorder — a consequence of our policies toward guns and lack of a social safety net. Compounding this is our longstanding educational dilemma, where urban schools generally lack the quality of suburban schools. American cities are simply much less family-friendly than cities in most other parts of the advanced world. So when people have kids, they are more or less forced to move out of America’s cities.<br>
>>[!note]
>>
</p><br>

>[!quote]
>many urban central business districts are “relics of the past, the last gasp of the industrial age organization of knowledge work, the veritable packing and stacking of knowledge workers in giant office towers, made obsolete and unnecessary by new technologies.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>“Downtowns are evolving away from centers for work to actual neighborhoods. Jane Jacobs titled her seminal 1957 essay, which led in fact to ‘The Death and Life of Great American Cities,’ ‘Downtown Is for People’ — sounds about right to me.”<br>
>>[!note]
>>
</p>