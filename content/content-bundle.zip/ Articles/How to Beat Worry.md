URL: https://moretothat.com/how-to-beat-worry/
Author: [[Lawrence Yeo]]
Date: [[09-27-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>The reason why worry is such a difficult emotion to tackle is that awareness simply isn’t enough. To be aware of an emotion like anger often allows you to divorce its physiology from its poignancy, but being aware of your worry often has the opposite effect.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Worry is driven by the fear of uncertainty, and being aware of this fear is further acknowledgement that you don’t know what will happen next.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The antidote to worry is not to be passively aware of it, but to take proactive steps to fix it.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Even if you know that a concern is a small one (i.e. “I sent an email to my boss with a few typos”), any attempt to trivialize it won’t work because the concern itself isn’t what matters anymore. What matters is how the concern has led to the Bleak Thought (i.e. “My boss will think I’m an idiot from here on out”), and how that amplifies the importance of the event in question.<br>
>>[!note]
>>
</p><br>

>[!quote]
>a worrier’s mind is extremely sensitive to anticipation.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Since the mind is so attuned to how things may go wrong, a worrier feels like he’s perpetually waiting for something to happen.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Our role as mindful mechanics is to go in and break these loops. But you don’t do that by telling yourself, “Hey, stop being stupid and stop worrying.” That’s a useless imperative. The way you do it is to approach each leg of the decision tree and provide a game plan to handle each option. The antidote to worry is not shame, but self-compassion.<br>
>>[!note]
>>
</p><br>

>[!quote]
>By being patient and kind to yourself, you let go of the tendency to criticize and can see the rational solutions with more clarity.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The way I see it is through the lens of what I call the Three D’s:<br>
>>[!note]
>>
</p><br>

>[!quote]
>After a concern arises, you ask yourself if something can be done, and if the answer is “Yes,” some semblance of a solution will come to mind.<br>
>>[!note]
>>
</p><br>

>[!quote]
>When this happens, decide that this is the solution you will pursue.<br>
>>[!note]
>>
</p><br>

>[!quote]
>But now that you’ve made this decision, here’s the important part: For the next 24 hours, do nothing. Don’t act upon that decision at all.<br>
>>[!note]
>>
</p><br>

>[!quote]
>This is where you make the final decision by asking yourself these questions: How do you feel about the decision after doing nothing for 24 hours? Does it still feel like the right move to schedule that 1:1 with your boss to chat about what happened? Or does it feel unwarranted and overblown to do that?<br>
>>[!note]
>>
</p><br>

>[!quote]
>(1) When a worry arises, notice that there’s only one question that matters: “Is there anything I can do about it?”<br>
>>[!note]
>>
</p><br>

>[!quote]
>(2) If the answer is “Yes, I can do something about it,” then put your decision through the Three D’s.<br>
>>[!note]
>>
</p><br>

>[!quote]
>(3) If the answer is “No, I can’t do anything about it,” then replace the worry with a challenge to direct your attention to something more fruitful.<br>
>>[!note]
>>
</p>