URL: https://kyla.substack.com/p/what-does-gen-z-really-think-about
Author: [[Kyla Scanlon]]
Date: [[04-20-2023]]
Tags: [[Philosophy MOC]] [[Sociology MOC]] [[Worklife MOC]] 

>[!tip]
>good piece touching on [[essentialism]] and what matters or not to younger generations


## Highlights
<br>

>[!quote]
>This idea that nothing matters and is structurally whatever is essentialism.<br>
>>[!note]
>>
</p>