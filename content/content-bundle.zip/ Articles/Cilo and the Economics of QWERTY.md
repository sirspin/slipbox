URL: https://personal.utdallas.edu/~liebowit/knowledge_goods/david1985aer.htm
Author: [[Paul Allan David]]
Date: [[Invalid date]]
Tags: 

>[!tip]
>It’s interesting how things like QWERTY can become ingrained. Many people will never change their style of typing, even as technology progresses, simply because it’s too difficult.


## Highlights
<br>

>[!quote]
>The story of QWERTY is a rather intriguing one for economists. Despite the presence of the sort of externalities that standard static analysis tells us would interfere with the achievement of the socially optimal degree of system compatibility, competition in the absence of perfect futures markets drove the industry prematurely into standardization on the wrong system where decentralized decision making subsequently has sufficed to hold it.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Outcomes of this kind are not so exotic. For such things to happen seems only too possible in the presence of strong technical interrelatedness, scale economies, and irreversibilities due to learning and habituation.<br>
>>[!note]
>>
</p><br>

>[!quote]
>I believe there are many more QWERTY worlds lying out there in the past, at the very edges of the modern economic analyst's tidy universe; worlds we do not yet fully perceive or understand, but whose influence1 like that of dark stars, extends nonetheless to shape the visible orbits of our contemporary economic affairs.<br>
>>[!note]
>>
</p>