URL: https://jacobinmag.com/2021/12/organic-local-industrial-agriculture-farm-to-table/
Author: [[]]
Date: [[Invalid date]]
Tags: 


## Highlights
<br>

>[!quote]
>The solution proposed by Waters and other progressive food advocates is that food ought to cost more, thereby allowing farmers to pay better wages and spend more on ecological amenities. But this creates a false conflict between consumers and workers. A proletarian food politics for the Left would celebrate cheap food for the masses. It would acknowledge the brutality of agricultural work and would embrace a food system that supported workers’ struggles at the point of production and used technology in a way that improved the lot of ordinary workers.<br>
>>[!note]
>>
</p>