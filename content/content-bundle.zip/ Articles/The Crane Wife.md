URL: https://www.theparisreview.org/blog/2019/07/16/the-crane-wife/
Author: [[CJ Hauser]]
Date: [[07-16-2019]]
Tags: 

>[!tip]
>Good note on novel research


## Highlights
<br>

>[!quote]
>I went to Texas to study the whooping crane because I was researching a novel. In my novel there were biologists doing field research about birds and I had no idea what field research actually looked like and so the scientists in my novel draft did things like shuffle around great stacks of papers and frown. The good people of the Earthwatch organization assured me I was welcome on the trip and would get to participate in “real science” during my time on the gulf. But as I waited to be picked up by my team in Corpus Christi, I was nervous—I imagined everyone else would be a scientist or a birder and have daunting binoculars.<br>
>>[!note]
>>
</p>