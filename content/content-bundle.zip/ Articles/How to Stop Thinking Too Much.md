URL: https://www.raptitude.com/2022/11/how-to-stop-thinking-too-much/
Author: [[David Cain]]
Date: [[11-07-2022]]
Tags: [[Psychology MOC]] 


## Highlights
<br>

>[!quote]
>being caught up in your own thinking is like having been kidnapped and held hostage by the most boring person on earth.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Even the most incessant and reactive stream of mental talk can occasionally be helpful (although how it helps, exactly, is a bigger discussion). In any case, mental talk does seem to vary immensely between individuals, in style and tone.<br>
>>[!note]
>>
</p><br>

>[!quote]
>(a) most of us do experience some sort of mental talk, which habitually voices our impressions of the world, and (b) it sometimes dominates our experience in a very unpleasant way, especially when we’re feeling worry or anxiety.<br>
>>[!note]
>>
</p><br>

>[!quote]
>You do it like this: 1. Notice that you’ve been caught up in thinking (i.e. held hostage by the boring kidnapper) 2. Don’t worry about halting the thinking. Instead, direct your attention to any physical corner — of the room, a window frame, a shelf, any place where two or more lines converge. Spend a few seconds looking at the corner, noticing its simple shape and color. 3. Turn your gaze to a different corner, and look at it for a few seconds. 4. Move your gaze like this to eight or ten different corners, spending a few seconds glimpsing at each one. When you switch corners, turn your whole head, not just your eyes.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Corner Glimpsing also shows you that whether you’re stuck in your thoughts is really a question of where your attention is pointing, not whether there are thoughts occurring. The would-be kidnapper never runs out of stuff to say, but you’re the one who ultimately decides where the attention goes.<br>
>>[!note]
>>
</p>