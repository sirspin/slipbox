URL: https://visakanv.substack.com/p/are-you-serious
Author: [[Visakan Veerasamy]]
Date: [[01-08-2023]]
Tags: 


## Highlights
<br>

>[!quote]
>We do live in a world that’s full of unserious people.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Anybody can say that they’re serious. How can I demonstrate that I’m serious?<br>
>>[!note]
>>
</p><br>

>[!quote]
>When I say serious I don’t mean solemn and tedious. I mean something closer to ‘dynamic persistence’,<br>
>>[!note]
>>
</p>