URL: https://www.theatlantic.com/technology/archive/2022/10/phone-call-greeting-smartphone-technological-error/671910/
Author: [[Ian Bogost]]
Date: [[10-28-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>Technology is a condition.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Nothing really works, and nothing is truly broken either, but instead these miraculous machines we invented take on their own lives alongside us.<br>
>>[!note]
>>
</p><br>

>[!quote]
>that distress is also a comfort, for it offers a common murk in which each of us gropes for a handhold so as not to be consumed.<br>
>>[!note]
>>
</p>