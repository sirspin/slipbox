URL: https://www.theatlantic.com/ideas/archive/2023/02/state-licensing-requirements-cosmetologists-landscape-architecture/673196/
Author: [[Jerusalem Demsas]]
Date: [[02-24-2023]]
Tags: [[Education MOC]] [[Sociology MOC]] 

>[!tip]
>Such a good piece!


## Highlights
<br>

>[!quote]
>the assumption that barriers to entry, no matter their form, will necessarily increase the quality of services provided is flawed.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Occupational licensing springs from a permission-slip mentality that has infected American political institutions of all sorts. Permission slips to braid hair, permission slips to build affordable housing, permission slips to put solar panels on your roof … a country full of adults raising our hands waiting for someone to let us use the bathroom!<br>
>>[!note]
>>
</p>