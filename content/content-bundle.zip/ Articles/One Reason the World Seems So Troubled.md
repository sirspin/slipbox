URL: https://www.raptitude.com/2022/11/one-reason-the-world-seems-so-troubled/
Author: [[David Cain]]
Date: [[11-24-2022]]
Tags: 

>[!tip]
>Great piece on a new concept - [[Boogeyman-ing]]. Ties in nicely with thoughts on propaganda from [[Edward Bernays]].


## Highlights
<br>

>[!quote]
>A boogeyman is a threatening portrayal of a person or thing, created on purpose, to drive people away from something: a business or an industry, a political opinion, a behavior. The hope is that the image is so off-putting that you won’t look closely enough to realize it’s a caricature.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Your sense of “the way things are” is like a Hollywood horror movie, wherein a few disparate but memorable facts and images get connected, by large spans of inference and fiction, into an effective and satisfying story.<br>
>>[!note]
>>
</p><br>

>[!quote]
>contriving a story of the world in which the things you fear most are prominent and growing, can motivate you to serve their private goals, which are probably to click, condemn, or praise whatever it is they want clicked, condemned, or praised.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Boogeymongering has limitless rhetorical power because limitless anxiety can be generated from a small seed of any significantly intense fear, regardless of how often it actually materializes in your direct experience. It’s an ancient art, but it’s easier than ever today, now that our lives are increasingly spent not directly experiencing the world itself, but instead browsing monetized depictions of the world on electronic devices.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The human mind tends to fill in the blanks with bad things. This is negativity bias, which helped keep our ancestors alive.<br>
>>[!note]
>>
</p><br>

>[!quote]
>we inherited a mind tuned for false positives. The human mind sees a dark room and habitually populates it with monsters, barely aware that it doesn’t actually know what’s there — that the darkness is the not-seeing, the not-knowing.<br>
>>[!note]
>>
</p><br>

>[!quote]
>start by assuming that any news, activism, or political speech, right or wrong, is freely employing boogeymen.<br>
>>[!note]
>>
</p><br>

>[!quote]
>A second reasonable assumption: if you have a completely partisan take on a contentious issue — as in, you do not believe there are any oversights in your side’s argument, no tradeoffs or complexities that might lead a decent person to a different stance — then you have probably been boogeymanned into those feelings to some extent.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The boogeyman is a simple monster. Pure badness, pure wrongness.<br>
>>[!note]
>>
</p>