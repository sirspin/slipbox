URL: https://www.overcomingbias.com/2023/02/why-is-everyone-so-boring.html
Author: [[Robin Hanson]]
Date: [[02-02-2023]]
Tags: [[Psychology MOC]] [[Sociology MOC]] 


## Highlights
<br>

>[!quote]
>Centuries ago, while people could rest safe and show themselves at home, when traveling between towns they tried to look either look poor or well-defended, as bandits lay in wait. Even within towns, people without allies who acted unusually rich, assertive, and confident would induce others to try to trip them somehow.<br>
>>[!note]
>>
</p><br>

>[!quote]
>I propose that the main reason that most of us look more boring in public is that social predators lie in wait there.<br>
>>[!note]
>>
</p><br>

>[!quote]
>I see roughly three typical public stances: boring, lively, or outraged. Either you act boring, so the bandits will ignore you, you act lively, and invite bandit attacks, or you act outraged, and play a bandit yourself. Most big orgs and experts choose boring, and most everyone else who doesn't pick boring picks bandit, especially on social media. It takes unusual art, allies, and energy, in a word "eliteness", to survive while choosing lively. And that, my children, is why the world looks so boring.<br>
>>[!note]
>>
</p>