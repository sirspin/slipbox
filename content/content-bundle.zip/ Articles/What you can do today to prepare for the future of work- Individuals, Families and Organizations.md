URL: https://rossdawson.com/can-today-prepare-future-work-individuals-families-organizations/
Author: [[Ross Dawson]]
Date: [[01-31-2018]]
Tags: [[Education MOC]] [[Learning MOC]] [[Sociology MOC]] [[Worklife MOC]] 


## Highlights
<br>

>[!quote]
>All change brings challenges and opportunities. Given the exceptional pace of change in the world today, no-one can expect a job for life or even a consistent role for many years. Everyone will need to consistently enhance their skills and move on to new roles to keep pace with the world. We can heed basic guidelines that will serve us and our livelihoods as we move forward.<br>
>>[!note]
>>
</p>