URL: https://robkhenderson.substack.com/p/some-unsolicited-advice-on-unsolicited
Author: [[Rob Henderson]]
Date: [[11-27-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>anthropological and sociological evidence indicates that generally speaking, people detest constraints on their freedom.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Hunter-gatherer communities hate all forms of dominance. Hunter-gatherers generally believe it is wrong to coerce a person into doing what the person doesn’t want to do. They seldom even make direct suggestions, because it might sound like coercion.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Perhaps people can accept abstract rules in the form of local norms and legal codes. But if it has a human face, if an individual directly tries to tell us what to do, we are naturally inclined to resent it.<br>
>>[!note]
>>
</p><br>

>[!quote]
>psychologist Peter Gray has suggested that people seem to resent unsolicited advice more when it comes from loved ones. When strangers give us unsolicited advice, it doesn’t feel like a constraint on our autonomy, because we don’t care about pleasing them.<br>
>>[!note]
>>
</p>