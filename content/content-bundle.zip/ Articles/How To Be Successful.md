URL: https://blog.samaltman.com/how-to-be-successful
Author: [[Sam Altman]]
Date: [[01-24-2019]]
Tags: 


## Highlights
<br>

>[!quote]
>Exponential curves are the key to wealth generation.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Most people get bogged down in linear opportunities. Be willing to let small opportunities go to focus on potential step changes.<br>
>>[!note]
>>
</p><br>

>[!quote]
>If you don’t believe in yourself, it’s hard to let yourself have contrarian ideas about the future. But this is where most value gets created.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Self-belief alone is not sufficient—you also have to be able to convince other people of what you believe. All great careers, to some degree, become sales jobs.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Taking risks is important because it’s impossible to be right all the time—you have to try many things and adapt quickly as you learn more.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Almost everyone I’ve ever met would be well-served by spending more time thinking about what to focus on.<br>
>>[!note]
>>
</p><br>

>[!quote]
>To be willful, you have to be optimistic—hopefully this is a personality trait that can be improved with practice. I have never met a very successful pessimistic person.<br>
>>[!note]
>>
</p><br>

>[!quote]
>You get truly rich by owning things that increase rapidly in value. This can be a piece of a business, real estate, natural resource, intellectual property, or other similar things. But somehow or other, you need to own equity in something, instead of just selling your time. Time only scales linearly. The best way to make things that increase rapidly in value is by making things people want at scale.<br>
>>[!note]
>>
</p>