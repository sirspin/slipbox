URL: https://stephanango.com/evergreen-notes
Author: [[Stephan Ango]]
Date: [[09-17-2022]]
Tags: [[Aesthetics MOC]] [[Learning MOC]] [[Writing MOC]] 

>[!tip]
>Interesting piece on [[Evergreen Notes]]


## Highlights
<br>

>[!quote]
>Creativity is combinatory uniqueness<br>
>>[!note]
>>
</p><br>

>[!quote]
>Evergreen notes turn ideas into objects.<br>
>>[!note]
>>
</p>