URL: https://collabfund.com/blog/ideas-that-changed-my-life/
Author: [[Morgan Housel]]
Date: [[03-07-2018]]
Tags: 


## Highlights
<br>

>[!quote]
>Everyone belongs to a tribe and underestimates how influential that tribe is on their thinking.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Everything’s been done before. The scenes change but the behaviors and outcomes don’t.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Historian Niall Ferguson’s plug for his profession is that “The dead outnumber the living 14 to 1, and we ignore the accumulated experience of such a huge majority of mankind at our peril.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>Communicate more effectively than your competition.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Your personal experiences make up maybe 0.00000001% of what’s happened in the world but maybe 80% of how you think the world works.<br>
>>[!note]
>>
</p><br>

>[!quote]
>People believe what they’ve seen happen exponentially more than what they read about has happened to other people, if they read about other people at all. We’re all biased to our own personal history.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Start with the assumption that everyone is innocently out of touch and you’ll be more likely to explore what’s going on through multiple points of view, instead of cramming what’s going on into the framework of your own experiences.<br>
>>[!note]
>>
</p>