URL: https://harpers.org/archive/1932/10/in-praise-of-idleness/
Author: [[Bertrand Russell]]
Date: [[09-30-1932]]
Tags: 


## Highlights
<br>

>[!quote]
>In America men often work long hours even when they are already well-off; such men, naturally, are indignant at the idea of leisure for wage-earners except as the grim punishment of unemployment, in fact, they dislike leisure even for their sons.<br>
>>[!note]
>>
</p><br>

>[!quote]
>only a foolish asceticism, usually vicarious, makes us insist on work in excessive quantities now that the need no longer exists.<br>
>>[!note]
>>
</p>