URL: https://getmatter.com/email/28933508/?token=28933508%3A_L6Y42JI29YNfMtAmVgWRN6LlX8
Author: [[Paul Millerd]]
Date: [[08-06-2023]]
Tags: [[Philosophy MOC]] [[Sociology MOC]] 


## Highlights
<br>

>[!quote]
>I realize that one of the most important things I stumbled into was “finding the others.” If I could change one thing about my journey it would be to proactively seek out people who were working in non-traditional ways before I quit my job. My main source of inspiration before quitting was podcasts and while the intimate sounds of people sharing their unconventional recipes for life in my ear were inspiring there were not nearly as influential as hearing such stories in real life.<br>
>>[!note]
>>
</p>