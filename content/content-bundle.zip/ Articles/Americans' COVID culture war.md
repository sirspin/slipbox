URL: https://www.axios.com/newsletters/axios-vitals-86665a3a-f311-4dd3-a428-69897d013a5f.html?chunk=0&utm_term=twsocialshare
Author: [[Caitlin Owens]]
Date: [[Invalid date]]
Tags: 


## Highlights
<br>

>[!quote]
>The key factor determining how Americans have handled COVID-19 — more than race, education or even political affiliation — is where they get their news, according to an analysis of two years of data from our Axios/Ipsos Coronavirus Index.<br>
>>[!note]
>>
</p>