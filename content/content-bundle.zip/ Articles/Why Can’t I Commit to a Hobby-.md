URL: https://www.thecut.com/2020/01/why-its-so-hard-to-commit-to-a-hobby.html
Author: [[Katie Heaney]]
Date: [[01-31-2020]]
Tags: [[Life Design MOC]] [[Psychology MOC]] 


## Highlights
<br>

>[!quote]
>having a hobby is really good for you.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Hobbies make us happier because they contribute to our sense of identity; and because having a strong identity outside of work makes us more content at work, one could argue that having a hobby also makes for better employees.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Having an “enjoyable leisure activity” (a.k.a. a hobby) is good for your physical health, too — one 2009 study published in Psychosomatic Medicine found that people who reported pleasurable and frequent participation in hobbies were found to have lower blood pressure, as well as perceptions of better physical function.<br>
>>[!note]
>>
</p>