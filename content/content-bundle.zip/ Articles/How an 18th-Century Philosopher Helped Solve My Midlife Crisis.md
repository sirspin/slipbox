URL: https://www.theatlantic.com/magazine/archive/2015/10/how-david-hume-helped-me-solve-my-midlife-crisis/403195/
Author: [[Alison Gopnik]]
Date: [[10-01-2015]]
Tags: [[History MOC]] [[Philosophy MOC]] 


## Highlights
<br>

>[!quote]
>The young man’s name was David Hume. Somehow, during the next three years, he managed not only to recover but also, remarkably, to write his book. Even more remarkably, it turned out to be one of the greatest books in the history of philosophy: A Treatise of Human Nature. In his Treatise, Hume rejected the traditional religious and philosophical accounts of human nature. Instead, he took Newton as a model and announced a new science of the mind, based on observation and experiment. That new science led him to radical new conclusions. He argued that there was no soul, no coherent self, no “I.” “When I enter most intimately into what I call myself,” he wrote in the Treatise, “I always stumble on some particular perception or other, of heat or cold, light or shade, love or hatred, pain or pleasure. I never can catch myself at any time without a perception, and never can observe any thing but the perception.”<br>
>>[!note]
>>Should probably read [[A Treatise of Human Nature]] by [[David Hume]]
</p><br>

>[!quote]
>But here’s Hume’s really great idea: Ultimately, the metaphysical foundations don’t matter. Experience is enough all by itself. What do you lose when you give up God or “reality” or even “I”? The moon is still just as bright; you can still predict that a falling glass will break, and you can still act to catch it; you can still feel compassion for the suffering of others. Science and work and morality remain intact. Go back to your backgammon game after your skeptical crisis, Hume wrote, and it will be exactly the same game.<br>
>>[!note]
>>
</p>