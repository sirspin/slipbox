URL: https://www.theguardian.com/books/2023/jan/26/living-for-pleasure-by-emily-a-austin-an-epicurean-guide-to-happiness
Author: [[Julian Baggini]]
Date: [[01-26-2023]]
Tags: 


## Highlights
<br>

>[!quote]
>Pursue what is of real value to you, not what society tells you is most important.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Epicurus’s distinctive feature is his insistence that pleasure is the source of all happiness and is the only truly good thing. Hence the modern use of “epicurean” to mean gourmand.<br>
>>[!note]
>>
</p><br>

>[!quote]
>He thought the greatest pleasure was ataraxia: a state of tranquility in which we are free from anxiety.<br>
>>[!note]
>>
</p><br>

>[!quote]
>freedom from anxiety sounds pretty attractive. How can we get it? Mainly by satisfying the right desires and ignoring the rest.<br>
>>[!note]
>>
</p><br>

>[!quote]
>“Those who least need extravagance enjoy it most,” the philosopher writes. Believing that only haute cuisine is good enough for you is a recipe for dissatisfaction.<br>
>>[!note]
>>
</p>