URL: https://nintil.com/cozy-futurism
Author: [[José Luis Ricón]]
Date: [[Invalid date]]
Tags: 


## Highlights
<br>

>[!quote]
>cozy futurism, as in the original tweet, starts not with technology but with current problems and human needs and looking at how those could be solved and met;<br>
>>[!note]
>>
</p><br>

>[!quote]
>Cozy futurism is not necessarily less ambitious than cool sci-fi futurism;<br>
>>[!note]
>>
</p><br>

>[!quote]
>Cozy futurism is distinct from solarpunk; solar punk seems to stress a retrofuturistic aesthetic, some sense of return to nature, perhaps smaller cooperatives instead of large corporations, a sense of self-reliance, urban agriculture, or distributed, renewable-based power grids. I'd say that cozy futurism is a subset of solarpunk, and that one could imagine multiple cozily futuristic ideologies or aesthetics, solarpunk being one.<br>
>>[!note]
>>
</p><br>

>[!quote]
>the goal is a nice future, not just a technically advanced future.<br>
>>[!note]
>>
</p>