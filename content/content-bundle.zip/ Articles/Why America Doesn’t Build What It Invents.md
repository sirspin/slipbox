URL: https://www.theatlantic.com/newsletters/archive/2022/12/us-progress-scientific-breakthrough-implementation-nuclear-fusion/672484/
Author: [[Derek Thompson]]
Date: [[12-16-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>progress is as much about implementation as it is about invention.<br>
>>[!note]
>>
</p><br>

>[!quote]
>the way that individuals and institutions take an idea from one to 1 billion is the real story of progress.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Inspired by the success of the government program to accelerate the development of the COVID vaccines, what would an Operation Warp Speed for cancer prevention look like?<br>
>>[!note]
>>
</p>