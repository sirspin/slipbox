URL: https://medium.com/@Jude.M/read-this-if-you-struggle-with-finishing-things-you-start-a0fdaa83aa6a
Author: [[Jude King]]
Date: [[05-30-2019]]
Tags: 


## Highlights
<br>

>[!quote]
>The Construal Level Theory (CLT) is a theory in social psychology that describes the relation between psychological distance and the extent to which a person’s thinking is abstract or concrete. Its key premise is that we perceive distant objects or events as abstract, intangible, unobservable, and with broad concepts whereas, we perceive close/near objects or events with concrete, specific, and observable features.<br>
>>[!note]
>>
</p><br>

>[!quote]
>We perceive the project or goal that we’re currently working on in the near-mode, whereas we perceive the project/goal that, as yet, exist only in our imagination in the distant-mode. When you move a goal/project from the imagination (where you are just thinking about it) into the real life (where you start to work on it), you move from a distant-mode perception to a near-mode perception.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The near-mode perception of your current project makes it specific, concrete and tangible. You see it in all the vivid details: now that you actually have to wake up daily to hit the gym rather than just fantasizing about being fit, the daily grind is no longer as fun. You are actually having to sit down and code rather than the fantasy of being a top programmer.<br>
>>[!note]
>>
</p><br>

>[!quote]
>In contrast, the new project ideas and goals now popping around in your head doesn’t have any of these drawbacks.<br>
>>[!note]
>>
</p><br>

>[!quote]
>In this fantasy world of imagination, there’s no complexity, no drawbacks, no difficulty. Only bliss.<br>
>>[!note]
>>
</p><br>

>[!quote]
>when you start on a new goal and your perception shifts from distant-mode to near-mode, you move from fantasy to seeing gritty details and it suddenly dawn that the goal/project isn’t as glamorous as you thought.<br>
>>[!note]
>>
</p>