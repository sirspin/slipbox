URL: https://ez.substack.com/p/the-scumbag-economy
Author: [[Ed Zitron]]
Date: [[10-12-2022]]
Tags: [[Sociology MOC]] [[Worklife MOC]]


## Highlights
<br>

>[!quote]
>When workers began to quit their jobs and take their business - the business of providing labor for money - elsewhere, they were accused of a lack of loyalty, and for participating in a pandemic-level “great resignation.” Leaders accused workers of “staying at home in their pajamas” with no justification, all while the companies they worked for made large amounts of money.<br>
>>[!note]
>>
</p><br>

>[!quote]
>And when they were done making money, they kicked the same workers out the front door, claiming that “tough times required tough decisions and efficiency,” a thing that didn’t seem to matter when it came to remote work, or over-hiring to scoop up profits, or massive marketing spends.<br>
>>[!note]
>>
</p><br>

>[!quote]
>While businesses may have received significant relief from COVID, immediately followed by a legendary year of profits, regular people existed in an alternate universe where their money didn’t go as far and things were harder to find. Want to know why people are “quiet quitting”? It’s probably because working for you sucks, and recent world history has shown that the people who work hard are not the same ones that succeed.<br>
>>[!note]
>>
</p><br>

>[!quote]
>if you want people to work hard you should pay them and treat them well.<br>
>>[!note]
>>
</p>