URL: https://www.nytimes.com/2007/07/08/books/review/Murakami-t.html
Author: [[Haruki Murakami]]
Date: [[07-08-2007]]
Tags: 


## Highlights
<br>

>[!quote]
>Still, I had no idea how to go about writing a novel or what to write about. I had absolutely no experience, after all, and no ready-made style at my disposal. I didn’t know anyone who could teach me how to do it, or even friends I could talk with about literature. My only thought at that point was how wonderful it would be if I could write like playing an instrument.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Whether in music or in fiction, the most basic thing is rhythm.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Your style needs to have good, natural, steady rhythm, or people won’t keep reading your work. I learned the importance of rhythm from music — and mainly from jazz.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Next comes melody — which, in literature, means the appropriate arrangement of the words to match the rhythm.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Next is harmony — the internal mental sounds that support the words.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Then comes the part I like best: free improvisation. Through some special channel, the story comes welling out freely from inside. All I have to do is get into the flow.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Finally comes what may be the most important thing: that high you experience upon completing a work — upon ending your “performance” and feeling you have succeeded in reaching a place that is new and meaningful.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Practically everything I know about writing, then, I learned from music. It may sound paradoxical to say so, but if I had not been so obsessed with music, I might not have become a novelist.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Once, when someone asked him how he managed to get a certain special sound out of the piano, Monk pointed to the keyboard and said: “It can’t be any new note. When you look at the keyboard, all the notes are there already. But if you mean a note enough, it will sound different. You got to pick the notes you really mean!”<br>
>>[!note]
>>
</p>