URL: https://ianleslie.substack.com/p/the-struggle-to-be-human
Author: [[Ian Leslie]]
Date: [[12-10-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>Here’s the thing: ChatGPT is casting a light on the problem of bullshit writing by humans.<br>
>>[!note]
>>
</p>