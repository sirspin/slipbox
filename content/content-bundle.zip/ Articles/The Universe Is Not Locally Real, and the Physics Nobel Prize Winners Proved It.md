URL: https://www.scientificamerican.com/article/the-universe-is-not-locally-real-and-the-physics-nobel-prize-winners-proved-it/
Author: [[Daniel Garisto]]
Date: [[10-06-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>The trouble with quantum mechanics was never that it made the wrong predictions—in fact, the theory described the microscopic world splendidly well right from the start when physicists devised it in the opening decades of the 20th century.<br>
>>[!note]
>>
</p><br>

>[!quote]
>What Einstein, Boris Podolsky and Nathan Rosen took issue with, laid out in their iconic 1935 paper, was the theory’s uncomfortable implications for reality.<br>
>>[!note]
>>
</p>