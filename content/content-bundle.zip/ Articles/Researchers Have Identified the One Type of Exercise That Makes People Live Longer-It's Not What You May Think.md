URL: https://www.outsideonline.com/health/wellness/social-fitness-happiness-longevity-waldinger/
Author: [[Svati Narula]]
Date: [[01-26-2023]]
Tags: 


## Highlights
<br>

>[!quote]
>Strengthening relationship ties by exercising what experts call “social fitness” is the most influential brain and body hack.<br>
>>[!note]
>>
</p><br>

>[!quote]
>“If you regularly feel isolated and lonely, it can be as dangerous as smoking half a pack of cigarettes a day or being obese,” Waldinger cautions.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Across the study, neither wealth nor social class were correlated with happiness levels or longevity. Positive relationships, on the other hand, were consistently linked to happier, longer lives.<br>
>>[!note]
>>
</p><br>

>[!quote]
>One systematic research review from 2010, including over 300,000 participants, suggests people with strong social ties are 50 percent more likely to survive over a given period than those with weak ties.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Rather than aim for a total social rehaul, focus on improving the valued relationships you already have.<br>
>>[!note]
>>
</p><br>

>[!quote]
>A great way to level up—and maintain—healthy relationships is by scheduling regular contact, virtual or in-person.<br>
>>[!note]
>>
</p><br>

>[!quote]
>One exercise to keep your social muscles in good shape is by expanding your network.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Do “emotional push-ups.” These include striking up conversations with strangers, saying thank you, or accepting compliments without deflection. Start small—Practice one or two emotional push-ups weekly.<br>
>>[!note]
>>
</p>