URL: https://perell.com/essay/never-ending-now/
Author: [[David Perell]]
Date: [[Invalid date]]
Tags: [[Sociology MOC]] [[Technology MOC]] 


## Highlights
<br>

>[!quote]
>With just a couple taps, we can transform our relationship with time, ignite our sense of history and escape the Never-Ending Now.<br>
>>[!note]
>>
</p>