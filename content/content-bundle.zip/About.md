---
home: true
---

Welcome to the Slipbox. This is a space-within-a-space of my note folder – a home for ruminating out loud. 

[Email me](mailto: turney.spencer@gmail.com)
